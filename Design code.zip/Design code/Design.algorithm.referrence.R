##################################
## simulation procedures
##################################

hazard.function.control<-function(t,k,h0)
  ## the hazard function of the control group
  ## t:the survival time
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
{
  return(k*h0*(h0*t)^(k-1))
}

hazard.function.treatment<-function(t,k,h0,t1,t2,theta,a,b)
  ## the hazard function of the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t:the survival time
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  if(t1==t2)
  {
    h0t=k*h0*(h0*t)^(k-1)
    h1t=theta*h0t
    return((t<t1)*h0t+(t>=t1)*h1t)
  }
  else
  {
    h0t=k*h0*(h0*t)^(k-1)
    t.std=(t-t1)/(t2-t1)
    lt=0*(t<=t1)+pbeta(t.std,a,b)*(t1<t & t<=t2)+(t>t2)
    h1t=(1-lt+theta*lt)*h0t
  }
  return(h1t)
}

cum.hazard.function.treatment<-function(t,k,h0,t1,t2,theta,a,b)
  ## the cumulative hazard function of the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  try.result=try(integrate(f=hazard.function.treatment,lower=0,upper=t,k,h0,t1,t2,theta,a,b,stop.on.error=FALSE)$value,silent = FALSE)
  if('try-error' %in% class(try.result))
  {
    return(Inf)
  }
  else
  {
    cum.hazard.treatment.unit=try.result
    return(cum.hazard.treatment.unit)
  }
}

cum.hazard.function.treatment.ref<-function(t,k,h0,t1,t2,theta,a,b,Cum.Hazd)
  ## the standardialized cumulative hazard function of the treatment group, which is used to produce the survival time
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  return(cum.hazard.function.treatment(t,k,h0,t1,t2,theta,a,b)-Cum.Hazd)
}

survival.function.control<-function(t,k,h0)
  ## the survival function of the control group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
{
  return(exp(-(h0*t)^k))
}

survival.function.treatment<-function(t,k,h0,t1,t2,theta,a,b)
  ## the survival function of the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  if(length(t)==1)
  {
    survival.proportion=exp(-(cum.hazard.function.treatment(t,k,h0,t1,t2,theta,a,b)))
    return(survival.proportion)
  }
  else
  {
    n=length(t)
    survival.proportion<-rep(NA,n)
    for(i in 1:n)
    {
      survival.proportion[i]=exp(-(cum.hazard.function.treatment(t[i],k,h0,t1,t2,theta,a,b)))
    }
    return(survival.proportion)
  }
}

survival.time.control<-function(n,k,h0)
  ## -n:number of observations. If length(n) > 1, the length is taken to be the number required
  ## -rate0:rates before the time of change
  ## -k:the weibull shape parameter
{
  U=runif(n)
  radnm=(-log(U))^(1/k)/h0
  return(radnm)
}

survival.time.treatment<-function(n,k,h0,t1,t2,theta,a,b)
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  if(theta==1)
  {
    U=runif(n)
    survival.time=(-log(U))^(1/k)/h0
  }
  else
  {
    U=runif(n)
    Cum.Hazd=-log(U)
    survival.time<-rep(NA,n)
    for(i in 1:n)
    {
      survival.time[i]=uniroot(f=cum.hazard.function.treatment.ref,interval=c(0,10000),k,h0,t1,t2,theta,a,b,Cum.Hazd[i])$root
    }
  }
  return(list(survival.time=survival.time,survival.proportion=U))
}


rpoipross<-function(n,rate)
  ## produce the entry time points accroding to the Poisson process
  ## -n:the number of time points
  ## -rate:intensity
{
  if(length(n)!=1)
    stop("n is not one parameter.")
  if(length(rate)!=1)
    stop("rate is not one parameter.")
  if(is.integer(n))
  {
    stop("n is not integer!")
  }
  if(n<=0)
  {
    stop("n is not bigger than 0")
  }
  if(!is.double(rate))
  {
    stop("rate is not a decimal or integer")
  }
  if(rate<=0)
  {
    stop("rate is not bigger than 0")
  }
  t=0
  S=rep(0,n)
  for(i in c(1:n))
  {
    U<-runif(1)
    t=t-log(U)/rate
    S[i]=t
  }
  return (S)
}

dataset.produce<-function(nc,nt,accrual.type,A,tau,loss.control,loss.treatment,k,h0,t1,t2,theta,a,b)
  ## produce the dataset used for the hypothesis in the Monte-Carlo simulation-procedure
  ## nc,nt:the sample sizes of the control and treatment groups
  ## accrual.type:select the way of how patients enter ths study
  ## c(0):patients enter the study according to the poisson process
  ## c(1,a):patients enter the study according to the distribution of F(x)=(x/A)^a
  ## A: the recruitment time(restricted to an integer)
  ## tau:the duration of the whole clinical trial(restricted to an integer)
  ## split.num: the splitted number of an unit period for an Markov chain
  ## loss.control: the rate of loss to follow-up in an unit period for the control group
  ## loss.treatment: the rate of loss to follow-up in an unit period for the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
## t1,t2:the minimum and maximum delay time
## theta: the hazard ratio after complete onset of the treatment effect
## a,b:the shape parameter of the distribution of the delay time
{
  datasetc<-matrix(nrow=nc,ncol=7)
  datasett<-matrix(nrow=nt,ncol=7)
  datasetc[,1]=rep(1,nc)## "1" represents the control group 
  datasett[,1]=rep(0,nt)## "0" represents the treatment group 
  h.loss.control=-log(1-loss.control)## the hazard constant of loss to follow-up in the control group
  h.loss.treatment=-log(1-loss.treatment)## the hazard constant of loss to follow-up in the treatment group
  ##produce the initial survival time of two groups
  datasetc[,2]=survival.time.control(nc,k,h0)
  datasett[,2]=survival.time.treatment(nt,k,h0,t1,t2,theta,a,b)$survival.time
  ##produce the recruitment time of two groups
  if(accrual.type[1]==0)
  {
    ##produce the entry time of control group and treatment group by poisson process
    entry=rpoipross(nc+nt,(nc+nt)/A)
    entry.total.order=c(1:(nc+nt))## original order number of two groups
    entry.control.order=sample(entry.total.order,nc)## select the order number corresponding to the entry time of the control group randomly
    entry.treatment.order=entry.total.order[-match(entry.control.order,entry.total.order)]## the rest is the order number of the treatment group
    entry.treatment.order=entry.treatment.order[sample(1:nt)]## permutate the order number of the treatment group
    datasetc[,3]=entry[entry.control.order]## get the entry number of the control group
    datasett[,3]=entry[entry.treatment.order]## get the entry number of the treatment group
  }
  else
  {
    a=accrual.type[2]
    datasetc[,3]=A*(runif(nc,0,1))^(1/a)
    datasett[,3]=A*(runif(nt,0,1))^(1/a)
  }
  ## produce the random censoring time
  datasetc[,4]=rexp(nc,h.loss.control)
  datasett[,4]=rexp(nt,h.loss.treatment)
  ## if the survial time is longer than the  censor time,the subject is censored;uncersored vice versa
  datasetc[,5]= datasetc[,2]<datasetc[,4]
  datasett[,5]= datasett[,2]<datasett[,4]
  ## obtain the observed time since the recruitment
  datasetc[,6]=apply(cbind(datasetc[,2],datasetc[,4]),1,min)
  datasett[,6]=apply(cbind(datasett[,2],datasett[,4]),1,min)
  ## obtain the observed time since the beginning of the clinical trial
  datasetc[,7]=datasetc[,6]+datasetc[,3]
  datasett[,7]=datasett[,6]+datasett[,3]
  dataset.whole=matrix(nrow=nc+nt,ncol=8)## the whole dataset of the control arm and the treatment arm 
  dataset.cb0=rbind(datasett,datasetc)## combine two datasets
  dataset.cb=dataset.cb0[order(dataset.cb0[,7]),]## sort the matrix by the column,which represents "the end time of actual visit"
  dataset.whole[,1]=seq(1,nc+nt)## the order number of two groups
  dataset.whole[,2:8]=dataset.cb##the data need to store
  colnames(dataset.whole)=c("order.number","group","survival.time","entry.time","censorring.time","censor.or.death","actual.observed.time.since.recruitment","actual.observed.time.since.begining")
  return(dataset.whole)
}

Maximin.efficiency.robust.test<-function(dataset.input,t.low,t.upper)
  ## This function is used to calculate the value of the Maximin efficiency robust test
  ## dataset.input: the dataset used to survival analysis
  ## t.low: the minimum delay time
  ## t.upper: the maximum delay time
{
  dataset.analysis<-dataset.input[,c(2,6,7)]## group, censor.or.death, actual.observed.time.since.recruitment
  dataset.analysis<-dataset.analysis[order(dataset.analysis[,3]),]
  number.uncensored<-sum(dataset.analysis[,2]==1)## get the number of uncensored subject
  nc<-sum(dataset.analysis[,1]==1)
  ne<-sum(dataset.analysis[,1]==0)
  nc.tir<-nc
  ne.tir<-ne
  Calc.matrix<-matrix(nrow=nc+ne,ncol=11)
  colnames(Calc.matrix)<-c("pc","pe","pc.pe","psi","censor.or.not","t1_t2","greater.t2","Group","weight","Ustd.unit","Variance.unit")
  Calc.matrix[1,1]=nc.tir/(nc.tir+ne.tir)
  Calc.matrix[1,2]=ne.tir/(nc.tir+ne.tir)
  Calc.matrix[1,3]=nc.tir*ne.tir/(nc.tir+ne.tir)^2
  Calc.matrix[1,4]=Calc.matrix[1,3]*dataset.analysis[1,2]
  Calc.matrix[1,5]=dataset.analysis[1,2]
  Time.obs=dataset.analysis[1,3]
  Calc.matrix[1,6]=Time.obs>=t.low & Time.obs<=t.upper
  Calc.matrix[1,7]=Time.obs>t.upper
  Calc.matrix[1,8]=dataset.analysis[1,1]
  nc.tir=nc.tir-dataset.analysis[1,1]
  ne.tir=ne.tir-(1-dataset.analysis[1,1])
  for(i in 2:(nc+ne))
  {
    Calc.matrix[i,1]=nc.tir/(nc.tir+ne.tir)
    Calc.matrix[i,2]=ne.tir/(nc.tir+ne.tir)
    Calc.matrix[i,3]=nc.tir*ne.tir/(nc.tir+ne.tir)^2
    Calc.matrix[i,4]=Calc.matrix[i,3]*dataset.analysis[i,2]+Calc.matrix[i-1,4]
    Calc.matrix[i,5]=dataset.analysis[i,2]
    Time.obs=dataset.analysis[i,3]
    Calc.matrix[i,6]=Time.obs>=t.low & Time.obs<=t.upper
    Calc.matrix[i,7]=Time.obs>t.upper
    Calc.matrix[i,8]=dataset.analysis[i,1]
    nc.tir=nc.tir-dataset.analysis[i,1]
    ne.tir=ne.tir-(1-dataset.analysis[i,1])
  }
  Calc.matrix[,4]=Calc.matrix[,4]/(nc+ne)
  psi.tau<-Calc.matrix[nc+ne,4]
  if(sum(Calc.matrix[,6])==0)
  {
    psi.t1=0
    psi.t2=0
  }
  else
  {
    psi.t1<-ifelse(min(which(Calc.matrix[,6]==1))==1,0,Calc.matrix[min(which(Calc.matrix[,6]==1))-1,4])
    psi.t2<-Calc.matrix[max(which(Calc.matrix[,6]==1)),4]
  }
  Calc.matrix[,9]=sqrt((psi.tau-psi.t1)/(psi.tau-Calc.matrix[,4]*Calc.matrix[,6]))*Calc.matrix[,6]+2*sqrt((psi.tau-psi.t1)/(psi.tau-psi.t2))*Calc.matrix[,7]
  Calc.matrix[,10]=Calc.matrix[,9]*(Calc.matrix[,8]-Calc.matrix[,1])*Calc.matrix[,5]
  Calc.matrix[,11]=Calc.matrix[,9]^2*Calc.matrix[,3]*Calc.matrix[,5]
  Value.unstd<-sum(Calc.matrix[,10])
  var.H0<-sum(Calc.matrix[,11])
  Sw_value<-Value.unstd/sqrt(var.H0)
  return(list(Sw_value=Sw_value,death.all=number.uncensored,num.recru=(nc+ne),Sw.ustd=Value.unstd,SW.Var.H0=var.H0,Calc.matrix=Calc.matrix,psi.t2=psi.t2,psi.t1=psi.t1,psi.tau=psi.tau))
}

MERT.Monte.Carlo.simulation<-function(order,nc,nt,accrual.type,A,tau,loss.control,loss.treatment,k,h0,t1,t2,t1.true,t2.true,theta,a,b)
  ## Simulate a fixed sample trial and calculate the maximin efficiency robust test statistics at the given calendar driven (parallel version)
  ## order: the order number of simulation
  ## nc,nt:the sample sizes of the control and treatment groups
  ## accrual.type:select the way of how patients enter ths study
  ## c(0):patients enter the study according to the poisson process
  ## c(1,a):patients enter the study according to the distribution of F(x)=(x/A)^a
  ## A: the recruitment time(restricted to an integer)
  ## tau:the duration of the whole clinical trial(restricted to an integer)
  ## loss.control: the rate of loss to follow-up in an unit period for the control group
  ## loss.treatment: the rate of loss to follow-up in an unit period for the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time(used in the MRET test)
  ## t1.true,t2.true:the minimum and maximum delay time (used in the generation of the dataset)
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  analysis.time=tau
  dataset.whole<-dataset.produce(nc,nt,accrual.type,A,tau,loss.control,loss.treatment,k,h0,t1.true,t2.true,theta,a,b)
  dataset.analysis<-dataset.whole[dataset.whole[,4]<=analysis.time,]
  dataset.analysis[dataset.analysis[,8]>analysis.time,6]=0
  dataset.analysis[dataset.analysis[,8]>analysis.time,7]=analysis.time-dataset.analysis[dataset.analysis[,8]>analysis.time,4]
  dataset.analysis[dataset.analysis[,8]>analysis.time,8]=analysis.time
  test.statistic=Maximin.efficiency.robust.test(dataset.input=dataset.analysis,t.low=t1,t.upper=t2)
  Sw_value=test.statistic$Sw_value
  Sw.ustd=test.statistic$Sw.ustd
  SW.Var.H0=test.statistic$SW.Var.H0
  Events.number.total=test.statistic$death.all
  return(c(order=order,Sw_value=Sw_value,Sw.ustd=Sw.ustd,SW.Var.H0=SW.Var.H0,Events.number.total=Events.number.total))
}

library(parallel)
fixed.sample.size.trial.Monte.Carlo.simulation.parallel<-function(nc,nt,accrual.type,A,tau,loss.control,loss.treatment,k,h0,t1,t2,t1.true,t2.true,theta,a,b,sides,alpha,simnum)
  # this function is used to simulate the fixed sample trial(parallel version)
  ## nc,nt:the sample sizes of the control and treatment groups
  ## accrual.type:select the way of how patients enter ths study
  ## c(0):patients enter the study according to the poisson process
  ## c(1,a):patients enter the study according to the distribution of F(x)=(x/A)^a
  ## A: the recruitment time(restricted to an integer)
  ## tau:the duration of the whole clinical trial(restricted to an integer)
  ## loss.control: the rate of loss to follow-up in an unit period for the control group
  ## loss.treatment: the rate of loss to follow-up in an unit period for the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time(used in the MRET test;default to t1.true and t2.true for the log-rank test)
  ## t1.true,t2.true:the minimum and maximum delay time (used in the generation of the dataset)
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time  
  ## alpha: the significance level
  ## sides: 1:right-sided test;2:two-sided test
  ## simnum: the number of repetitions in the Monte-Carlo simulation procedure
{
  if(sides==1)## the right side
  {
    lowerbound=-Inf## get the lower boundary of the group sequential design
    upperbound=qnorm(1-alpha)## get the upper boundary of the group sequential design
  }
  else if(sides==2)## the two sides
  {
    upperbound<-qnorm(1-alpha/2) ## get the upper boundary of the group sequential design
    lowerbound<--qnorm(1-alpha/2) ## get the lower boundary of the group sequential design
  }
  analysis.time=tau
  core.num=50
  varlist=c("Maximin.efficiency.robust.test","hazard.function.control","hazard.function.treatment","cum.hazard.function.treatment","cum.hazard.function.treatment.ref","survival.function.control","survival.function.treatment","survival.time.control","survival.time.treatment","rpoipross","dataset.produce","MERT.Monte.Carlo.simulation")
  ## MRET test
  cl<-makeCluster(getOption("cl.cores",core.num))
  clusterExport(cl,varlist=varlist,envir=environment())
  simul.res.list=parLapply(cl,seq(1,simnum,1),MERT.Monte.Carlo.simulation,nc,nt,accrual.type,A,tau,loss.control,loss.treatment,k,h0,t1,t2,t1.true,t2.true,theta,a,b)
  stopCluster(cl)
  Simul.res <- do.call(rbind,simul.res.list)
  test.statistics.simulation<-Simul.res[,2]
  Decision.simulation=!(Simul.res[,2]<=upperbound&lowerbound<=Simul.res[,2])
  Sw.ustd.simulation=Simul.res[,3]
  SW.Var.H0.simulation=Simul.res[,4]
  Events.number.total.simulation=Simul.res[,5]
  Power=mean(Decision.simulation)## the emprical power
  analysis.time.pred=analysis.time
  Events.pred=mean(Events.number.total.simulation)
  Mean.H1.std=mean(test.statistics.simulation)
  Var.H1.std=var(test.statistics.simulation)
  Mean.H1.ustd=mean(Sw.ustd.simulation)
  Var.H1.ustd=var(Sw.ustd.simulation)
  Var.H0.ustd=mean(SW.Var.H0.simulation)
  Var.Var.H0.ustd=var(SW.Var.H0.simulation)
  Empirical.Distribution=list(Mean.H1.std=Mean.H1.std,Var.H1.std=Var.H1.std,Mean.H1.ustd=Mean.H1.ustd,Var.H1.ustd=Var.H1.ustd,Var.H0.ustd=Var.H0.ustd,Var.Var.H0.ustd=Var.Var.H0.ustd,log.rank.ustd=Sw.ustd.simulation,Var.H0.simulation=SW.Var.H0.simulation)
  Initial.data=list(test.statistics.simulation=test.statistics.simulation,Sw.ustd.simulation=Sw.ustd.simulation,SW.Var.H0.simulation=SW.Var.H0.simulation)
  Parameters.list=list(nc=nc,nt=nt,accrual.type=accrual.type,A=A,tau=tau,loss.control=loss.control,loss.treatment=loss.treatment,k=k,h0=h0,t1=t1,t2=t2,t1.true=t1.true,t2.true=t2.true,theta=theta,a=a,b=b,sides=sides,alpha=alpha,simnum=simnum)
  return(list(Power=Power,analysis.time.pred=analysis.time.pred,Events.pred=Events.pred,Parameters.list=Parameters.list,Empirical.Distribution=Empirical.Distribution,Initial.data=Initial.data))
}

## Ye and Yu (2018) sample estimation algorithm
Ye.Yu.Sample.size.estimation<-function(A,tau,loss.control,loss.treatment,k,h0,t1,t2,theta,a,b,Allc,alpha,power,sides)
  ## A: the recruitment time(restricted to an integer)
  ## tau:the duration of the whole clinical trial(restricted to an integer)
  ## loss.control: the rate of loss to follow-up in an unit period for the control group
  ## loss.treatment: the rate of loss to follow-up in an unit period for the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2: the minimum and maximum delay time(which is used in the MERT)
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time (these parameters are really not useful in this algorithm)
  ## Allc: the allocation ratio of the sample sizes of the treatment and control groups
  ## alpha: the significance level
  ## power: the nominal power
  ## sides: 1:right-sided test;2:two-sided test
{
  h2.control=-log(1-loss.control)## The random censoring hazard of the control group
  h2.treatment=-log(1-loss.treatment)## The random censoring hazard of the treatment group
  p=Allc/(1+Allc)
  G.control<-function(t)
  {
    Surv.random.censor<-exp(-h2.control*t)
    surv.adm.censor<-punif(t,min=tau-A,max=tau,lower.tail=FALSE)
    return(Surv.random.censor*surv.adm.censor)
  }
  G.treatment<-function(t)
  {
    Surv.random.censor<-exp(-h2.treatment*t)
    surv.adm.censor<-punif(t,min=tau-A,max=tau,lower.tail=FALSE)
    return(Surv.random.censor*surv.adm.censor)
  }
  phi.integrand<-function(t)
  {
    integrand<-hazard.function.control(t,k,h0)*p*(1-p)*survival.function.control(t,k,h0)*G.control(t)*G.treatment(t)
    integrand<-integrand/(p*G.treatment(t)+(1-p)*G.control(t))
    return(integrand)
  }
  phi<-function(t)
  {
    num=length(t)
    phi=rep(NA,num)
    for(i in 1:num)
    {
      phi[i]<-integrate(phi.integrand,lower=0,upper=t[i])$value
    }
    return(phi)
  }
  ratio_d2n<-function(t)
  {
    death.prop.control.integrand<-function(t)
    {
      result=G.control(t)*hazard.function.control(t,k,h0)*survival.function.control(t,k,h0)
      return(result)
    }
    ratio_c_d2n<-integrate(death.prop.control.integrand,lower=t2,upper=tau)$value
    death.prop.treatment.integrand<-function(t)
    {
      ## The lag function should be considered as the extreme scenario
      result=G.treatment(t)*hazard.function.treatment(t,k,h0,t2,t2,theta,a,b)*survival.function.treatment(t,k,h0,t2,t2,theta,a,b)
      return(result)
    }
    ratio_t_d2n<-integrate(death.prop.treatment.integrand,lower=t2,upper=tau)$value
    ratio_pool_d2n<-p*ratio_t_d2n+(1-p)*ratio_c_d2n
    return(ratio_pool_d2n)
  }
  ratio_t2.tilde<-ratio_d2n(t2.tilde)
  rho_MERT.square<-(phi(tau)-phi(t2))/(phi(tau)-phi(t1))
  rho.MERT<-sqrt(rho_MERT.square)  
  if(sides==2)
  {
    D2=(2-log(rho.MERT))*(qnorm(1-alpha/2)+qnorm(power))^2/(2*p*(1-p)*log(theta)^2)
    n=D2/ratio_t2.tilde
  }
  else
  {
    D2=(2-log(rho.MERT))*(qnorm(1-alpha)+qnorm(power))^2/(2*p*(1-p)*log(theta)^2)
    n=D2/ratio_t2.tilde
  }
  n=ceiling(n)
  nc=round(n/(Allc+1))
  nt=n-nc
  return(list(n=n,nc=nc,nt=nt,D2=ceiling(D2),rho.MERT=rho.MERT,ratio_t2.tilde=ratio_t2.tilde))
}
library (statmod)
## Ding and Wu (2020) sample estimation algorithm
Ding.Wu.sample.size.estimation<-function(A,tau,loss.control,loss.treatment,k,h0,t1,t1.true,t2,t2.true,theta,a,b,Allc,alpha,power,sides)
  ## A: the recruitment time(restricted to an integer)
  ## tau:the duration of the whole clinical trial(restricted to an integer)
  ## loss.control: the rate of loss to follow-up in an unit period for the control group
  ## loss.treatment: the rate of loss to follow-up in an unit period for the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2: the minimum and maximum delay time(which is used in the MERT)
  ## t1.true,t2.true:the minimum and maximum delay time(which is used in the delay function l(t) and the generation of the Markov chain)
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
  ## Allc: the allocation ratio of the sample sizes of the treatment and control groups
  ## alpha: the significance level
  ## power: the nominal power
  ## sides: 1:right-sided test;2:two-sided test
{
  pc<-1/(1+Allc)
  pt<-Allc/(1+Allc)
  h2.control=-log(1-loss.control)## The random censoring hazard of the control group
  h2.treatment=-log(1-loss.treatment)## The random censoring hazard of the treatment group
  G.control<-function(t)
  {
    Surv.random.censor<-exp(-h2.control*t)
    surv.adm.censor<-punif(t,min=tau-A,max=tau,lower.tail=FALSE)
    return(Surv.random.censor*surv.adm.censor)
  }
  G.treatment<-function(t)
  {
    Surv.random.censor<-exp(-h2.treatment*t)
    surv.adm.censor<-punif(t,min=tau-A,max=tau,lower.tail=FALSE)
    return(Surv.random.censor*surv.adm.censor)
  }
  phi.integrand<-function(t)
  {
    integrand<-pc*hazard.function.control(t,k,h0)*survival.function.control(t,k,h0)*G.control(t)
    integrand<-integrand+pt*G.treatment(t)*hazard.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)*survival.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    integrand<-integrand*pc*pt
    return(integrand)
  }
  phi<-function(t)
  {
    num=length(t)
    phi=rep(NA,num)
    for(i in 1:num)
    {
      phi[i]<-integrate(phi.integrand,lower=0,upper=t[i])$value
    }
    return(phi)
  }
  MERT.weight<-function(t)
  {
    num=length(t)
    weight<-rep(0,num)
    for(i in 1:num)
    {
      if(t[i]<=t2&&t[i]>t1)
      {
        weight[i]<-((phi(tau)-phi(t[i]))/(phi(tau)-phi(t1)))^(-1/2)
      }
      else if(t[i]>t2)
      {
        weight[i]<-2*((phi(tau)-phi(t2))/(phi(tau)-phi(t1)))^(-1/2)
      }
    }
    return(weight)
  }
  pai<-function(t)
  {
    survival.control<-survival.function.control(t,k,h0)
    survival.treatment<-survival.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    num=length(t)
    pai=rep(NA,num)
    for(i in 1:num)
    {
      if(t[i]==tau)
      {
        pai[i]=pc*survival.control[i]/(pc*survival.control[i]+pt*survival.treatment[i])
      }
      else
      {
        pai[i]=pc*survival.control[i]*G.control(t[i])/(pc*survival.control[i]*G.control(t[i])+pt*survival.treatment[i]*G.treatment(t[i]))
      }
    }
    return(pai)
  }
  V.t<-function(t)
  {
    survival.control<-survival.function.control(t,k,h0)
    survival.treatment<-survival.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    hazard.control<-hazard.function.control(t,k,h0)
    hazard.treatment<-hazard.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    Survival.censor.control<-G.control(t)
    Survival.censor.treatment<-G.treatment(t)
    V.t=pc*survival.control*hazard.control*Survival.censor.control+pt*survival.treatment*hazard.treatment*Survival.censor.treatment
    return(V.t)
  }
  mu.w.integrand<-function(t)
  {
    hazard.control<-hazard.function.control(t,k,h0)
    hazard.treatment<-hazard.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    integrand<-MERT.weight(t)*pai(t)*(1-pai(t))*(hazard.control-hazard.treatment)*V.t(t)/(pai(t)*hazard.control+(1-pai(t))*hazard.treatment)
    return(integrand)
  }
  sigma2.H0.w.integrand<-function(t)
  {
    integrand=MERT.weight(t)^2*pai(t)*(1-pai(t))*V.t(t)
    return(integrand)
  }
  ## The numeric integration function defined by Ding and Wu(2020)
  quad.points=50
  GQ<-gauss.quad(n=quad.points, kind="legendre")
  GQ.int<-function(g, limits)
  {
    upp=limits[2]; 
    low=limits[1];
    sum(sapply(GQ$nodes, function(s){g((upp-low)*s/2+(upp+low)/2)*(upp-low)/2})*GQ$weights)
  }
  bandry=matrix(c(0, tau), 1,2)
  mu.w=sum(apply(bandry, 1, function(x) GQ.int(mu.w.integrand, x)))
  #mu.w=integrate(mu.w.integrand,lower=0,upper=tau)$value
  sigma2.H0.w=sum(apply(bandry, 1, function(x) GQ.int(sigma2.H0.w.integrand, x)))
  #sigma2.H0.w=integrate(sigma2.H0.w.integrand,lower=0,upper=tau)$value
  if(sides==2)
  {
    n.est=sigma2.H0.w*(qnorm(1-alpha/2)+qnorm(power))^2/mu.w^2
    
  }
  else
  {
    n.est=sigma2.H0.w*(qnorm(1-alpha)+qnorm(power))^2/mu.w^2
  }
  n=ceiling(n.est)
  nc=round(n/(Allc+1))
  nt=n-nc
  Pt0=integrate(V.t, t2.true, tau)$value
  dt0=ceiling(n*Pt0)
  d=ceiling(dt0+(1-survival.function.treatment(t2.true,k,h0,t1.true,t2.true,theta,a,b))*n)
  return(list(n=n,nc=nc,nt=nt,d=d))
}

## Schoenfeld (1981) sample estimation algorithm
Schoenfeld.sample.size.estimation<-function(A,tau,loss.control,loss.treatment,k,h0,t1,t1.true,t2,t2.true,theta,a,b,Allc,alpha,power,sides)
  ## A: the recruitment time(restricted to an integer)
  ## tau:the duration of the whole clinical trial(restricted to an integer)
  ## loss.control: the rate of loss to follow-up in an unit period for the control group
  ## loss.treatment: the rate of loss to follow-up in an unit period for the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2: the minimum and maximum delay time(which is used in the MERT)
  ## t1.true,t2.true:the minimum and maximum delay time(which is used in the delay function l(t) and the generation of the Markov chain)
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
  ## Allc: the allocation ratio of the sample sizes of the treatment and control groups
  ## alpha: the significance level
  ## power: the nominal power
  ## sides: 1:right-sided test;2:two-sided test
{
  pc<-1/(1+Allc)
  pt<-Allc/(1+Allc)
  h2.control=-log(1-loss.control)## The random censoring hazard of the control group
  h2.treatment=-log(1-loss.treatment)## The random censoring hazard of the treatment group
  G.control<-function(t)
  {
    Surv.random.censor<-exp(-h2.control*t)
    surv.adm.censor<-punif(t,min=tau-A,max=tau,lower.tail=FALSE)
    return(Surv.random.censor*surv.adm.censor)
  }
  G.treatment<-function(t)
  {
    Surv.random.censor<-exp(-h2.treatment*t)
    surv.adm.censor<-punif(t,min=tau-A,max=tau,lower.tail=FALSE)
    return(Surv.random.censor*surv.adm.censor)
  }
  phi.integrand<-function(t)
  {
    integrand<-pc*hazard.function.control(t,k,h0)*survival.function.control(t,k,h0)*G.control(t)
    integrand<-integrand+pt*G.treatment(t)*hazard.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)*survival.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    integrand<-integrand*pc*pt
    return(integrand)
  }
  phi<-function(t)
  {
    num=length(t)
    phi=rep(NA,num)
    for(i in 1:num)
    {
      phi[i]<-integrate(phi.integrand,lower=0,upper=t[i])$value
    }
    return(phi)
  }
  MERT.weight<-function(t)
  {
    num=length(t)
    weight<-rep(0,num)
    for(i in 1:num)
    {
      if(t[i]<=t2&&t[i]>t1)
      {
        weight[i]<-((phi(tau)-phi(t[i]))/(phi(tau)-phi(t1)))^(-1/2)
      }
      else if(t[i]>t2)
      {
        weight[i]<-2*((phi(tau)-phi(t2))/(phi(tau)-phi(t1)))^(-1/2)
      }
    }
    return(weight)
  }
  pai<-function(t)
  {
    survival.control<-survival.function.control(t,k,h0)
    survival.treatment<-survival.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    num=length(t)
    pai=rep(NA,num)
    for(i in 1:num)
    {
      if(t[i]==tau)
      {
        pai[i]=pc*survival.control[i]/(pc*survival.control[i]+pt*survival.treatment[i])
      }
      else
      {
        pai[i]=pc*survival.control[i]*G.control(t[i])/(pc*survival.control[i]*G.control(t[i])+pt*survival.treatment[i]*G.treatment(t[i]))
      }
    }
    return(pai)
  }
  V.t<-function(t)
  {
    survival.control<-survival.function.control(t,k,h0)
    survival.treatment<-survival.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    hazard.control<-hazard.function.control(t,k,h0)
    hazard.treatment<-hazard.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    Survival.censor.control<-G.control(t)
    Survival.censor.treatment<-G.treatment(t)
    V.t=pc*survival.control*hazard.control*Survival.censor.control+pt*survival.treatment*hazard.treatment*Survival.censor.treatment
    return(V.t)
  }
  mu.w.integrand<-function(t)
  {
    hazard.control<-hazard.function.control(t,k,h0)
    hazard.treatment<-hazard.function.treatment(t,k,h0,t1.true,t2.true,theta,a,b)
    integrand<-MERT.weight(t)*pai(t)*(1-pai(t))*log(hazard.control/hazard.treatment)*V.t(t)
    return(integrand)
  }
  sigma2.H0.w.integrand<-function(t)
  {
    integrand=MERT.weight(t)^2*pai(t)*(1-pai(t))*V.t(t)
    return(integrand)
  }
  ## The numeric integration function defined by Ding and Wu(2020)
  quad.points=50
  GQ<-gauss.quad(n=quad.points, kind="legendre")
  GQ.int<-function(g, limits)
  {
    upp=limits[2]; 
    low=limits[1];
    sum(sapply(GQ$nodes, function(s){g((upp-low)*s/2+(upp+low)/2)*(upp-low)/2})*GQ$weights)
  }
  bandry=matrix(c(0, tau), 1,2)
  mu.w=sum(apply(bandry, 1, function(x) GQ.int(mu.w.integrand, x)))
  sigma2.H0.w=sum(apply(bandry, 1, function(x) GQ.int(sigma2.H0.w.integrand, x)))
  if(sides==2)
  {
    n.est=sigma2.H0.w*(qnorm(1-alpha/2)+qnorm(power))^2/mu.w^2
    
  }
  else
  {
    n.est=sigma2.H0.w*(qnorm(1-alpha)+qnorm(power))^2/mu.w^2
  }
  n=ceiling(n.est)
  nc=round(n/(Allc+1))
  nt=n-nc
  Pt0=integrate(V.t, t2.true, tau)$value
  dt0=ceiling(n*Pt0)
  d=ceiling(dt0+(1-survival.function.treatment(t2.true,k,h0,t1.true,t2.true,theta,a,b))*n)
  return(list(n=n,nc=nc,nt=nt,d=d))
}