##################################
## simulation procedures
##################################

hazard.function.control.pweibull<-function(t,k1,h1,k2,h2,k3,h3,tstar1,tstar2)
{
  num=length(t)
  hazard=rep(NA,num)
  for(i in 1:num)
  {
    if(t[i]<=tstar1)
    {
      hazard[i]=k1*h1*(h1*t[i])^(k1-1)
    }
    else if(t[i]<=tstar2)
    {
      hazard[i]=k2*h2*(h2*t[i])^(k2-1)
    }
    else
    {
      hazard[i]=k3*h3*(h3*t[i])^(k3-1)
    }
  }
  return(hazard)
}

cum.hazard.function.control.pweibull<-function(t,k1,h1,k2,h2,k3,h3,tstar1,tstar2)
{
  num=length(t)
  cum.hazard=rep(NA,num)
  for(i in 1:num)
  {
    if(t[i]<=tstar1)
    {
      cum.hazard[i]=(h1*t[i])^k1
    }
    else if(t[i]<=tstar2)
    {
      cum.hazard[i]=(h1*tstar1)^k1+(h2*t[i])^k2-(h2*tstar1)^k2
    }
    else
    {
      cum.hazard[i]=(h1*tstar1)^k1+(h2*tstar2)^k2-(h2*tstar1)^k2+(h3*t[i])^k3-(h3*tstar2)^k3
    }
  }
  return(cum.hazard)
}

hazard.function.treatment.pweibull<-function(t,k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1,t2,theta,a,b)
{
  h0t=hazard.function.control.pweibull(t,k1,h1,k2,h2,k3,h3,tstar1,tstar2)
  if(t1==t2)
  {
    h1t=(t<t1)*h0t+(t>=t1)*theta*h0t
  }
  else
  {
    t.std=(t-t1)/(t2-t1)
    lt=pbeta(t.std,a,b)
    h1t=(1-lt+theta*lt)*h0t
  }
  return(h1t)
}

cum.hazard.function.treatment.pweibull<-function(t,k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1,t2,theta,a,b,stop.on.error=TRUE)
{
  num=length(t)
  cum.hazard.treatment.unit<-rep(NA,num)
  for(i in 1:num)
  {
    cum.hazard.treatment.unit[i]<-integrate(f=hazard.function.treatment.pweibull,lower=0,upper=t[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1,t2,theta,a,b,stop.on.error=stop.on.error,subdivisions=10000)$value
  }
  return(cum.hazard.treatment.unit)
}

survival.function.control.pweibull<-function(t,k1,h1,k2,h2,k3,h3,tstar1,tstar2)
{
  cum.hazard=cum.hazard.function.control.pweibull(t,k1,h1,k2,h2,k3,h3,tstar1,tstar2)
  return(exp(-cum.hazard))
}

survival.function.treatment.pweibull<-function(t,k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1,t2,theta,a,b,stop.on.error=TRUE)
{
  n=length(t)
  survival.proportion<-rep(NA,n)
  for(i in 1:n)
  {
    survival.proportion[i]=exp(-(cum.hazard.function.treatment.pweibull(t[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1,t2,theta,a,b,stop.on.error)))
  }
  return(survival.proportion)
}

## Joint Parameters estimation for the survival data of the immunotherapy and control group using the general lag model and generalized delayed treatment effect function
Joint.Parameters.estimation.pweibull<-function(Observation.time,Censoring.identicator,Group)
{
  logLik.novel<-function(parameters)
  {
    k1=parameters[1]
    h1=parameters[2]
    k2=parameters[3]
    h2=parameters[4]
    k3=parameters[5]
    h3=parameters[6]
    tstar1=parameters[7]
    tstar2=parameters[7]+parameters[8]
    theta=parameters[9]
    t1.true=parameters[10]
    dif.t1.t2=parameters[11]
    t2.true=t1.true+dif.t1.t2
    a=parameters[12]
    b=parameters[13]
    print(paste("k1=",k1,";h1=",h1,";k2=",k2,";h2=",h2,";k3=",k3,";h3=",h3,";tstar1=",tstar1,";tstar2=",tstar2,";theta=",theta,";t1.true=",t1.true,";t2.true=",t2.true,";a=",a,";b=",b))
    log.Likelihood=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      if(Group[i]==0)
      {
        ## Control group
        cum.hazard=cum.hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
      else
      {
        ## Immunotherapy group
        cum.hazard=cum.hazard.function.treatment.pweibull(t=Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.treatment.pweibull(Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
    }
    print(-log.Likelihood)
    return(-log.Likelihood)
  }
  logLik.novel.not.stop.on.error<-function(parameters)
  {
    k1=parameters[1]
    h1=parameters[2]
    k2=parameters[3]
    h2=parameters[4]
    k3=parameters[5]
    h3=parameters[6]
    tstar1=parameters[7]
    tstar2=parameters[7]+parameters[8]
    theta=parameters[9]
    t1.true=parameters[10]
    dif.t1.t2=parameters[11]
    t2.true=t1.true+dif.t1.t2
    a=parameters[12]
    b=parameters[13]
    #print(paste("k1=",k1,";h1=",h1,";k2=",k2,";h2=",h2,";k3=",k3,";h3=",h3,";tstar1=",tstar1,";tstar2=",tstar2,";theta=",theta,";t1.true=",t1.true,";t2.true=",t2.true,";a=",a,";b=",b))
    log.Likelihood=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      if(Group[i]==0)
      {
        ## Control group
        cum.hazard=cum.hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
      else
      {
        ## Immunotherapy group
        cum.hazard=cum.hazard.function.treatment.pweibull(t=Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b,stop.on.error = FALSE)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.treatment.pweibull(Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
    }
    print(-log.Likelihood)
    return(-log.Likelihood)
  }
  logLik.novel.try<-function(parameters)
  {
    try.result1=try(logLik.novel(parameters),silent=FALSE)
    if('try-error' %in% class(try.result1))
    {
      print("Conduction!")
      try.result2=try(logLik.novel.not.stop.on.error(parameters),silent=FALSE)
      if('try-error' %in% class(try.result2))
      {
        print(Inf)
        return(Inf)
      }
      else
      {
        return(try.result2)
      }
    }
    else
    {
      return(try.result1)
    }
  }
  library(Rmalschains)
  lower=c(0.01,0.01,0.01,0.01,0.01,0.01,2,0.01,0.2,0.01,0.01,0.01,0.01)
  names(lower)<-c("k1","h1","k2","h2","k3","h3","tstar1","dif.tstar12","theta","t1.true","dif.t1.t2","a","b")
  upper=c(10,10,10,100,10,10,3,6,0.9,3,10,100,100)
  names(upper)<-c("k1","h1","k2","h2","k3","h3","tstar1","dif.tstar12","theta","t1.true","dif.t1.t2","a","b")
  MLE.novel=malschains(fn=logLik.novel.try, lower=lower, upper=upper)
  return(MLE.novel)
}

## Joint Parameters estimation for the survival data of the immunotherapy and control group using the general lag model and generalized delayed treatment effect function
Joint.Parameters.estimation.pweibull.maxLik<-function(initial.values,Observation.time,Censoring.identicator,Group)
{
  logLik.novel<-function(parameters)
  {
    k1=parameters[1]
    h1=parameters[2]
    k2=parameters[3]
    h2=parameters[4]
    k3=parameters[5]
    h3=parameters[6]
    tstar1=parameters[7]
    tstar2=parameters[7]+parameters[8]
    theta=parameters[9]
    t1.true=parameters[10]
    dif.t1.t2=parameters[11]
    t2.true=t1.true+dif.t1.t2
    a=parameters[12]
    b=parameters[13]
    print(paste("k1=",k1,";h1=",h1,";k2=",k2,";h2=",h2,";k3=",k3,";h3=",h3,";tstar1=",tstar1,";tstar2=",tstar2,";theta=",theta,";t1.true=",t1.true,";t2.true=",t2.true,";a=",a,";b=",b))
    log.Likelihood=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      if(Group[i]==0)
      {
        ## Control group
        cum.hazard=cum.hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
      else
      {
        ## Immunotherapy group
        cum.hazard=cum.hazard.function.treatment.pweibull(t=Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.treatment.pweibull(Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
    }
    print(log.Likelihood)
    return(log.Likelihood)
  }
  library(maxLik)
  ineqA=matrix(0,nrow=13,ncol=13)
  for(i in 1:13)
  {
    ineqA[i,i]=1
  }
  ineqB=rep(0,13)
  MLE.novel=maxLik(logLik=logLik.novel, start=initial.values,method="BFGS",constraints=list(ineqA=ineqA,ineqB=ineqB))
  return(MLE.novel)
}

## Joint Parameters estimation for the survival data of the immunotherapy and control group using the general lag model and generalized lag pattern
Joint.Parameters.estimation.pweibull.Ye.Yu<-function(Observation.time,Censoring.identicator,Group)
{
  logLik.novel<-function(parameters)
  {
    k1=parameters[1]
    h1=parameters[2]
    k2=parameters[3]
    h2=parameters[4]
    k3=parameters[5]
    h3=parameters[6]
    tstar1=parameters[7]
    tstar2=parameters[7]+parameters[8]
    theta=parameters[9]
    t1.true=parameters[10]
    dif.t1.t2=parameters[11]
    t2.true=t1.true+dif.t1.t2
    a=1
    b=1
    print(paste("k1=",k1,";h1=",h1,";k2=",k2,";h2=",h2,";k3=",k3,";h3=",h3,";tstar1=",tstar1,";tstar2=",tstar2,";theta=",theta,";t1.true=",t1.true,";t2.true=",t2.true,";a=",a,";b=",b))
    log.Likelihood=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      if(Group[i]==0)
      {
        ## Control group
        cum.hazard=cum.hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
      else
      {
        ## Immunotherapy group
        cum.hazard=cum.hazard.function.treatment.pweibull(t=Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.treatment.pweibull(Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
    }
    print(-log.Likelihood)
    return(-log.Likelihood)
  }
  logLik.novel.not.stop.on.error<-function(parameters)
  {
    k1=parameters[1]
    h1=parameters[2]
    k2=parameters[3]
    h2=parameters[4]
    k3=parameters[5]
    h3=parameters[6]
    tstar1=parameters[7]
    tstar2=parameters[7]+parameters[8]
    theta=parameters[9]
    t1.true=parameters[10]
    dif.t1.t2=parameters[11]
    t2.true=t1.true+dif.t1.t2
    a=1
    b=1
    #print(paste("k1=",k1,";h1=",h1,";k2=",k2,";h2=",h2,";k3=",k3,";h3=",h3,";tstar1=",tstar1,";tstar2=",tstar2,";theta=",theta,";t1.true=",t1.true,";t2.true=",t2.true,";a=",a,";b=",b))
    log.Likelihood=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      if(Group[i]==0)
      {
        ## Control group
        cum.hazard=cum.hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
      else
      {
        ## Immunotherapy group
        cum.hazard=cum.hazard.function.treatment.pweibull(t=Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b,stop.on.error = FALSE)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.treatment.pweibull(Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
    }
    print(-log.Likelihood)
    return(-log.Likelihood)
  }
  logLik.novel.try<-function(parameters)
  {
    try.result1=try(logLik.novel(parameters),silent=FALSE)
    if('try-error' %in% class(try.result1))
    {
      print("Conduction!")
      try.result2=try(logLik.novel.not.stop.on.error(parameters),silent=FALSE)
      if('try-error' %in% class(try.result2))
      {
        print(Inf)
        return(Inf)
      }
      else
      {
        return(try.result2)
      }
    }
    else
    {
      return(try.result1)
    }
  }
  library(Rmalschains)
  lower=c(0.01,0.01,0.01,0.01,0.01,0.01,2,0.01,0.2,0.01,0.01)
  names(lower)<-c("k1","h1","k2","h2","k3","h3","tstar1","dif.tstar12","theta","t1.true","dif.t1.t2")
  upper=c(10,10,10,100,10,10,3,6,0.9,3,10)
  names(upper)<-c("k1","h1","k2","h2","k3","h3","tstar1","dif.tstar12","theta","t1.true","dif.t1.t2")
  MLE.novel=malschains(fn=logLik.novel.try, lower=lower, upper=upper)
  return(MLE.novel)
}

## Joint Parameters estimation for the survival data of the immunotherapy and control group using the general lag model and generalized lag pattern
Joint.Parameters.estimation.pweibull.Ye.Yu.maxLik<-function(initial.values,Observation.time,Censoring.identicator,Group)
{
  logLik.novel<-function(parameters)
  {
    k1=parameters[1]
    h1=parameters[2]
    k2=parameters[3]
    h2=parameters[4]
    k3=parameters[5]
    h3=parameters[6]
    tstar1=parameters[7]
    tstar2=parameters[7]+parameters[8]
    theta=parameters[9]
    t1.true=parameters[10]
    dif.t1.t2=parameters[11]
    t2.true=t1.true+dif.t1.t2
    a=1
    b=1
    print(paste("k1=",k1,";h1=",h1,";k2=",k2,";h2=",h2,";k3=",k3,";h3=",h3,";tstar1=",tstar1,";tstar2=",tstar2,";theta=",theta,";t1.true=",t1.true,";t2.true=",t2.true,";a=",a,";b=",b))
    log.Likelihood=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      if(Group[i]==0)
      {
        ## Control group
        cum.hazard=cum.hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
      else
      {
        ## Immunotherapy group
        cum.hazard=cum.hazard.function.treatment.pweibull(t=Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
        log.Likelihood=log.Likelihood-cum.hazard
        if(Censoring.identicator[i]==1)
        {
          ## Uncensored event
          hazard=hazard.function.treatment.pweibull(Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,k3=k3,h3=h3,tstar1=tstar1,tstar2=tstar2,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
          log.Likelihood=log.Likelihood+log(hazard)
        }
      }
    }
    print(log.Likelihood)
    return(log.Likelihood)
  }
  logLik.novel.try<-function(parameters)
  {
    try.result1=try(logLik.novel(parameters),silent=FALSE)
    if('try-error' %in% class(try.result1))
    {
      print("Conduction!")
      try.result2=try(logLik.novel.not.stop.on.error(parameters),silent=FALSE)
      if('try-error' %in% class(try.result2))
      {
        print(Inf)
        return(Inf)
      }
      else
      {
        return(try.result2)
      }
    }
    else
    {
      return(try.result1)
    }
  }
  
  library(maxLik)
  ineqA=matrix(0,nrow=11,ncol=11)
  for(i in 1:11)
  {
    ineqA[i,i]=1
  }
  ineqB=rep(0,11)
  MLE.novel=maxLik(logLik=logLik.novel.try, start=initial.values,method="BFGS",constraints=list(ineqA=ineqA,ineqB=ineqB))
  return(MLE.novel)
}