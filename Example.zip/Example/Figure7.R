rm(list=ls())
setwd("D:/研究备份/研究3/固定样本设计/图表代码及结果")
load("Fit.Data.goodness.evaluation11.RData")
load("Fit.Data.goodness.evaluation11_2.RData")
parameters<-Joint.parameter.pweibull.local.optim$estimate
k1=round(parameters[1],2)
h1=round(parameters[2],2)
k2=round(parameters[3],2)
h2=round(parameters[4],2)
k3=round(parameters[5],2)
h3=round(parameters[6],2)
tstar1=round(parameters[7],2)
tstar2=round(parameters[7]+parameters[8],2)
theta=round(parameters[9],2)
t1.true=round(parameters[10],2)
dif.t1.t2=round(parameters[11],2)
t2.true=t1.true+dif.t1.t2
a=round(parameters[12],2)
b=round(parameters[13],2)
t.vec<-seq(0,20,0.1)
surv.frame<-data.frame(matrix(nrow=804,ncol=4))
colnames(surv.frame)<-c("t","Surv.prop","Group","Survival.model")
for(i in 1:201)
{
  surv.frame$t[i]=t.vec[i]
  surv.frame$Surv.prop[i]=survival.function.treatment.pweibull(t.vec[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1.true,t2.true,theta,a,b)*100
  surv.frame$Group[i]="Immunotherapy"
  surv.frame$Survival.model[i]="Proposed ~~ survival ~~ model"
}
for(i in 202:402)
{
  surv.frame$t[i]=t.vec[i-201]
  surv.frame$Surv.prop[i]=survival.function.control.pweibull(t.vec[i-201],k1,h1,k2,h2,k3,h3,tstar1,tstar2)*100
  surv.frame$Group[i]="Control"
  surv.frame$Survival.model[i]="Proposed ~~ survival ~~ model"
}
hazard.frame<-data.frame(matrix(nrow=804,ncol=4))
colnames(hazard.frame)<-c("t","hazard","Group","Survival.model")
for(i in 1:201)
{
  hazard.frame$t[i]=t.vec[i]
  hazard.frame$hazard[i]=hazard.function.treatment.pweibull(t.vec[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1.true,t2.true,theta,a,b)
  hazard.frame$Group[i]="Immunotherapy"
  hazard.frame$Survival.model[i]="Proposed ~~ survival ~~ model"
}
for(i in 202:402)
{
  hazard.frame$t[i]=t.vec[i-201]
  hazard.frame$hazard[i]=hazard.function.control.pweibull(t.vec[i-201],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
  hazard.frame$Group[i]="Control"
  hazard.frame$Survival.model[i]="Proposed ~~ survival ~~ model"
}
hazard.ratio.frame<-data.frame(matrix(NA,nrow=402,ncol=3))
hazard.ratio.frame[1,1]=0
hazard.ratio.frame[1,2]=1
hazard.ratio.frame[1,3]="Proposed ~~ survival ~~ model"
colnames(hazard.ratio.frame)<-c("t","hazard.ratio","Survival.model")
for(i in 2:201)
{
  hazard.ratio.frame$t[i]=t.vec[i]
  hazard.ratio.frame$hazard.ratio[i]=hazard.frame$hazard[i]/hazard.frame$hazard[i+201]
  hazard.ratio.frame$Survival.model[i]="Proposed ~~ survival ~~ model"
}
parameters<-Joint.parameter.pweibull.local.optim.Ye.Yu$estimate
k1=round(parameters[1],2)
h1=round(parameters[2],2)
k2=round(parameters[3],2)
h2=round(parameters[4],2)
k3=round(parameters[5],2)
h3=round(parameters[6],2)
tstar1=round(parameters[7],2)
tstar2=round(parameters[7]+parameters[8],2)
theta=round(parameters[9],2)
t1.true=round(parameters[10],2)
dif.t1.t2=round(parameters[11],2)
t2.true=t1.true+dif.t1.t2
a=1
b=1
for(i in 1:201)
{
  surv.frame$t[i+402]=t.vec[i]
  surv.frame$Surv.prop[i+402]=survival.function.treatment.pweibull(t.vec[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1.true,t2.true,theta,a,b)*100
  surv.frame$Group[i+402]="Immunotherapy"
  surv.frame$Survival.model[i+402]="Survival ~~ model ~~ of ~~ Ye ~~ and ~~ Yu(2018)"
}
for(i in 202:402)
{
  surv.frame$t[i+402]=t.vec[i-201]
  surv.frame$Surv.prop[i+402]=survival.function.control.pweibull(t.vec[i-201],k1,h1,k2,h2,k3,h3,tstar1,tstar2)*100
  surv.frame$Group[i+402]="Control"
  surv.frame$Survival.model[i+402]="Survival ~~ model ~~ of ~~ Ye ~~ and ~~ Yu(2018)"
}
for(i in 1:201)
{
  hazard.frame$t[i+402]=t.vec[i]
  hazard.frame$hazard[i+402]=hazard.function.treatment.pweibull(t.vec[i],k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1.true,t2.true,theta,a,b)
  hazard.frame$Group[i+402]="Immunotherapy"
  hazard.frame$Survival.model[i+402]="Survival ~~ model ~~ of ~~ Ye ~~ and ~~ Yu(2018)"
}
for(i in 202:402)
{
  hazard.frame$t[i+402]=t.vec[i-201]
  hazard.frame$hazard[i+402]=hazard.function.control.pweibull(t.vec[i-201],k1,h1,k2,h2,k3,h3,tstar1,tstar2)
  hazard.frame$Group[i+402]="Control"
  hazard.frame$Survival.model[i+402]="Survival ~~ model ~~ of ~~ Ye ~~ and ~~ Yu(2018)"
}
hazard.ratio.frame[202,1]=0
hazard.ratio.frame[202,2]=1
hazard.ratio.frame[202,3]="Survival ~~ model ~~ of ~~ Ye ~~ and ~~ Yu(2018)"
colnames(hazard.ratio.frame)<-c("t","hazard.ratio","Survival.model")
for(i in 2:201)
{
  hazard.ratio.frame$t[i+201]=t.vec[i]
  hazard.ratio.frame$hazard.ratio[i+201]=hazard.frame$hazard[i+402]/hazard.frame$hazard[i+603]
  hazard.ratio.frame$Survival.model[i+201]="Survival ~~ model ~~ of ~~ Ye ~~ and ~~ Yu(2018)"
}
library(ggplot2)
dev.set()
cairo_ps("Figure71_BoshengLi.eps",width=21,height=6.5)
p<-ggplot(surv.frame,aes(x=t,y=Surv.prop,colour=Group))+geom_line(linewidth=1)+xlab("Survival time (months)")+ylab("PFS (%)")
p<-p+theme(axis.title = element_text(size=24),axis.text = element_text(size=21),legend.text = element_text(size=21),legend.title=element_text(size=24),strip.text = element_text(size=24))
p<-p+facet_grid(~Survival.model,labeller = label_parsed)
p
dev.off()
dev.set()
cairo_ps("Figure72_BoshengLi.eps",width=21,height=6.5)
p<-ggplot(hazard.frame,aes(x=t,y=hazard,colour=Group))+geom_line(size=1)+xlab("Survival time (months)")+ylab("Hazard function")
p<-p+theme(axis.title = element_text(size=24),axis.text = element_text(size=21),legend.text = element_text(size=21),legend.title=element_text(size=24),strip.text = element_text(size=24))
p<-p+facet_grid(~Survival.model,labeller = label_parsed)
p
dev.off()
dev.set()
cairo_ps("Figure73_BoshengLi.eps",width=19,height=6.5)
p<-ggplot(hazard.ratio.frame,aes(x=t,y=hazard.ratio))+geom_line(size=1)+xlab("Survival time (months)")+ylab("Hazard ratio")
p<-p+theme(axis.title = element_text(size=24),axis.text = element_text(size=21),legend.text = element_text(size=21),legend.title=element_text(size=24),strip.text = element_text(size=24))
p<-p+facet_grid(~Survival.model,labeller = label_parsed)
p
dev.off()
