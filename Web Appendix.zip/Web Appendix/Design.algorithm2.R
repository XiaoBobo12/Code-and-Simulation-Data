library(markovchain)
##################################
## simulation procedures
##################################

hazard.function.control<-function(t,k,h0)
  ## the hazard function of the control group
  ## t:the survival time
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
{
  return(k*h0*(h0*t)^(k-1))
}

hazard.function.control.pweibull<-function(t,k1,h1,k2,h2,tstar)
{
  num=length(t)
  hazard=rep(NA,num)
  for(i in 1:num)
  {
    hazard[i]=(t[i]<tstar)*k1*h1*(h1*t[i])^(k1-1)+(t[i]>=tstar)*k2*h2*(h2*t[i])^(k2-1)
  }
  return(hazard)
}

cum.hazard.function.control<-function(t,k,h0)
  ## the survival function of the control group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
{
  return((h0*t)^k)
}

cum.hazard.function.control.pweibull<-function(t,k1,h1,k2,h2,tstar)
{
  num=length(t)
  cum.hazard=rep(NA,num)
  for(i in 1:num)
  {
    cum.hazard[i]=(t[i]<tstar)*(h1*t[i])^k1+(t[i]>=tstar)*((h1*tstar)^k1+(h2*t[i])^k2-(h2*tstar)^k2)
  }
  return(cum.hazard)
}

hazard.function.treatment<-function(t,k,h0,t1,t2,theta,a,b)
  ## the hazard function of the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t:the survival time
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  if(t1==t2)
  {
    h0t=k*h0*(h0*t)^(k-1)
    h1t=theta*h0t
    return((t<t1)*h0t+(t>=t1)*h1t)
  }
  else
  {
    h0t=k*h0*(h0*t)^(k-1)
    t.std=(t-t1)/(t2-t1)
    lt=0*(t<=t1)+pbeta(t.std,a,b)*(t1<t & t<=t2)+(t>t2)
    h1t=(1-lt+theta*lt)*h0t
  }
  return(h1t)
}

hazard.function.treatment.pweibull<-function(t,k1,h1,k2,h2,tstar,t1,t2,theta,a,b)
{
  h0t=hazard.function.control.pweibull(t,k1,h1,k2,h2,tstar)
  if(t1==t2)
  {
    h1t=(t<t1)*h0t+(t>=t1)*theta*h0t
  }
  else
  {
    t.std=(t-t1)/(t2-t1)
    lt=0*(t<=t1)+pbeta(t.std,a,b)*(t1<t & t<=t2)+(t>t2)
    h1t=(1-lt+theta*lt)*h0t
  }
  return(h1t)
}

cum.hazard.function.treatment<-function(t,k,h0,t1,t2,theta,a,b)
  ## the cumulative hazard function of the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  num=length(t)
  if(num==1)
  {
    cum.hazard.treatment.unit<-integrate(f=hazard.function.treatment,lower=0,upper=t,k,h0,t1,t2,theta,a,b)$value
  }
  else
  {
    cum.hazard.treatment.unit<-rep(NA,num)
    for(i in 1:num)
    {
      cum.hazard.treatment.unit[i]<-integrate(f=hazard.function.treatment,lower=0,upper=t[i],k,h0,t1,t2,theta,a,b)$value
    }
  }
  return(cum.hazard.treatment.unit)
}

cum.hazard.function.treatment.pweibull<-function(t,k1,h1,k2,h2,tstar,t1,t2,theta,a,b)
{
  num=length(t)
  cum.hazard.treatment.unit<-rep(NA,num)
  for(i in 1:num)
  {
    cum.hazard.treatment.unit[i]<-integrate(f=hazard.function.treatment.pweibull,lower=0,upper=t[i],k1,h1,k2,h2,tstar,t1,t2,theta,a,b)$value
  }
  return(cum.hazard.treatment.unit)
}
  
cum.hazard.function.treatment.ref<-function(t,k,h0,t1,t2,theta,a,b,Cum.Hazd)
  ## the standardialized cumulative hazard function of the treatment group, which is used to produce the survival time
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  return(cum.hazard.function.treatment(t,k,h0,t1,t2,theta,a,b)-Cum.Hazd)
}

survival.function.control<-function(t,k,h0)
  ## the survival function of the control group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
{
  return(exp(-(h0*t)^k))
}

survival.function.control.pweibull<-function(t,k1,h1,k2,h2,tstar)
{
  cum.hazard=cum.hazard.function.control.pweibull(t,k1,h1,k2,h2,tstar)
  return(exp(-cum.hazard))
}
  

survival.function.treatment<-function(t,k,h0,t1,t2,theta,a,b)
  ## the survival function of the treatment group
  ## k,h0: the survival function of the control group is assumed to be exp[-(h0*t)^k]
  ## t1,t2:the minimum and maximum delay time
  ## theta: the hazard ratio after complete onset of the treatment effect
  ## a,b:the shape parameter of the distribution of the delay time
{
  if(length(t)==1)
  {
    survival.proportion=exp(-(cum.hazard.function.treatment(t,k,h0,t1,t2,theta,a,b)))
    return(survival.proportion)
  }
  else
  {
    n=length(t)
    survival.proportion<-rep(NA,n)
    for(i in 1:n)
    {
      survival.proportion[i]=exp(-(cum.hazard.function.treatment(t[i],k,h0,t1,t2,theta,a,b)))
    }
    return(survival.proportion)
  }
}

survival.function.treatment.pweibull<-function(t,k1,h1,k2,h2,tstar,t1,t2,theta,a,b)
{
  n=length(t)
  survival.proportion<-rep(NA,n)
  for(i in 1:n)
  {
    survival.proportion[i]=exp(-(cum.hazard.function.treatment.pweibull(t[i],k1,h1,k2,h2,tstar,t1,t2,theta,a,b)))
  }
  return(survival.proportion)
}

Parameters.estimation.control.pWeibull<-function(k1.init,h1.init,k2.init,h2.init,tstar.init,Observation.time,Censoring.identicator,Group)
{
  logLik.control<-function(parameters,Observation.time,Censoring.identicator,Group)
  {
    k1=parameters[1]
    h1=parameters[2]
    k2=parameters[3]
    h2=parameters[4]
    tstar=parameters[5]
    print(paste("k1=",k1,";h1=",h1,";k2=",k2,";h2=",h2,";tstar=",tstar))
    log.Likelihood.control=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      surv=survival.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,tstar)
      log.Likelihood.control=log.Likelihood.control+log(surv)
      if(Censoring.identicator[i]==1)
      {
        ## Uncensored event
        hazard=hazard.function.control.pweibull(Observation.time[i],k1,h1,k2,h2,tstar)
        log.Likelihood.control=log.Likelihood.control+log(hazard)
      }
    }
    print(log.Likelihood.control)
    return(log.Likelihood.control)
  }
  library(maxLik)
  ineqA=rbind(c(1,0,0,0,0),c(0,1,0,0,0),c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1))
  ineqB=c(0,0,0,0,0)
  MLE.control=maxLik(logLik=logLik.control,start=c(k1.init,h1.init,k2.init,h2.init,tstar.init),method="BFGS",control=list(iterlim=500,tol=10^(-20)),constraints=list(ineqA=ineqA,ineqB=ineqB),Observation.time=Observation.time,Censoring.identicator=Censoring.identicator,Group=Group)
  return(MLE.control)
}

## Parameters estimation for the general lag model with the generalized lag function
Parameters.estimation.treatment<-function(theta.init,t1.init,t2.init,a.init,b.init,k,h0,Observation.time,Censoring.identicator,Group)
{
  logLik.novel<-function(parameters,Observation.time,Censoring.identicator,Group,k,h0)
  {
    theta=parameters[1]
    t1.true=parameters[2]
    t2.true=parameters[3]
    a=parameters[4]
    b=parameters[5]
    print(paste("theta=",theta,";t1.true=",t1.true,";t2.true=",t2.true,";a=",a,";b=",b))
    log.Likelihood.novel=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      ## "0" represents the treatment group 
      surv.novel=survival.function.treatment(Observation.time[i],k,h0,t1.true,t2.true,theta,a,b)
      log.Likelihood.novel=log.Likelihood.novel+log(surv.novel)
      if(Censoring.identicator[i]==1)
      {
        ## Uncensored event
        hazard.novel=hazard.function.treatment(Observation.time[i],k,h0,t1.true,t2.true,theta,a,b)
        log.Likelihood.novel=log.Likelihood.novel+log(hazard.novel)
      }
    }
    print(log.Likelihood.novel)
    return(log.Likelihood.novel)
  }
  library(maxLik)
  ineqA=rbind(c(1,0,0,0,0),c(0,1,0,0,0),c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1),c(0,-1,1,0,0))
  ineqB=c(0,0,0,0,0,0)
  if(t1.init==t2.init)
  {
    t1.init=t1.init-0.00001## In order to satisfy the restriction assumption
  }
  MLE.novel=maxLik(logLik=logLik.novel,start=c(theta.init,t1.init,t2.init,a.init,b.init),method="BFGS",control=list(iterlim=500),constraints=list(ineqA=ineqA,ineqB=ineqB),Observation.time=Observation.time,Censoring.identicator=Censoring.identicator,Group=Group,k=k,h0=h0)
  return(MLE.novel)
}

## Parameters estimation for the general lag model with the generalized lag function
Parameters.estimation.treatment.pweibull<-function(theta.init,t1.init,t2.init,a.init,b.init,k1,h1,k2,h2,tstar,Observation.time,Censoring.identicator,Group)
{
  logLik.novel<-function(parameters,Observation.time,Censoring.identicator,Group,k1,h1,k2,h2,tstar)
  {
    theta=parameters[1]
    t1.true=parameters[2]
    t2.true=parameters[3]
    a=parameters[4]
    b=parameters[5]
    print(paste("theta=",theta,";t1.true=",t1.true,";t2.true=",t2.true,";a=",a,";b=",b))
    log.Likelihood.novel=0
    n=length(Observation.time)
    for(i in 1:n)
    {
      surv.novel=survival.function.treatment.pweibull(Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,tstar=tstar,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
      
      log.Likelihood.novel=log.Likelihood.novel+log(surv.novel)
      if(Censoring.identicator[i]==1)
      {
        ## Uncensored event
        hazard.novel=hazard.function.treatment.pweibull(Observation.time[i],k1=k1,h1=h1,k2=k2,h2=h2,tstar=tstar,t1=t1.true,t2=t2.true,theta=theta,a=a,b=b)
        log.Likelihood.novel=log.Likelihood.novel+log(hazard.novel)
      }
    }
    print(log.Likelihood.novel)
    return(log.Likelihood.novel)
  }
  library(maxLik)
  ineqA=rbind(c(1,0,0,0,0),c(0,1,0,0,0),c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1),c(0,-1,1,0,0))
  ineqB=c(0,0,0,0,0,0)
  if(t1.init==t2.init)
  {
    t1.init=t1.init-0.00001## In order to satisfy the restriction assumption
  }
  MLE.novel=maxLik(logLik=logLik.novel,start=c(theta.init,t1.init,t2.init,a.init,b.init),method="BFGS",control=list(iterlim=500),constraints=list(ineqA=ineqA,ineqB=ineqB),Observation.time=Observation.time,Censoring.identicator=Censoring.identicator,Group=Group,k1=k1,h1=h1,k2=k2,h2=h2,tstar=tstar)
  return(MLE.novel)
}