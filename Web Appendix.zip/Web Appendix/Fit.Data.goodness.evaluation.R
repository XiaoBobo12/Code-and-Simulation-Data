rm(list=ls())
library(IPDfromKM)
library(survival)
library(ggplot2)
theme_set(theme_bw())
library(dplyr)
library(survival)
library(mgcv)
library(pammtools)
library(survminer)
library(survival)
library(mice)
setwd("D:/�о�����/�о�3/�̶��������/ģ���龰����/����ʾ��")
Treatment<-read.csv(file="Ipilimumab.csv",header=TRUE)
Control<-read.csv(file="Placepo.csv",header=TRUE)
trisk=seq(0,32,2)
nrisk.control=c(400,334,146,65,43,29,18,13,4,4,3,2,1,0,0,0,0)
nrist.treatment=c(399,326,192,111,87,65,45,34,28,16,13,9,8,6,5,2,0)
Control.proc<-preprocess(dat=Control,trisk=trisk,nrisk=nrisk.control,maxy=100)
Treatment.proc<-preprocess(dat=Treatment,trisk=trisk,nrisk=nrist.treatment,maxy=100)
Control.survival.data=getIPD(prep=Control.proc,armID=1)
Treatment.survival.data=getIPD(prep=Treatment.proc,armID=0)
survival.data.control<-Control.survival.data$IPD
survival.data.treatment<-Treatment.survival.data$IPD
Survival.data.overall=rbind(survival.data.control,survival.data.treatment)
survival.plot<-survfit(formula = Surv(Survival.data.overall$time,Survival.data.overall$status)~treat,data=Survival.data.overall)
print(ggsurvplot(survival.plot,font.x=14,font.y=14,font.legend=14,surv.scale="percent",break.x.by=2,break.y.by=0.1,xlim=c(0,32),axes.offset=TRUE,legend=c(0.8,0.93),legend.title="Therapy",legend.labs=c("Ipilimumab","Placebo"),xlab="Months since randomization",ylab="Patients without progression(%)"))
source("Design.algorithm2.R")
k.init=1.436759
h0.init=0.2112915
theta.init=0.23
t1.init=2.5
t2.init=6.5
a.init=3.5
b.init=1.5
Parameters.control<-Parameters.estimation.control.Weibull(k.init,h0.init,Observation.time=survival.data.control$time,Censoring.identicator=survival.data.control$status,Group=survival.data.control$treat)
k=Parameters.control$estimate[1]
h0=Parameters.control$estimate[2]
survival.data.control$cum.hazard.est=cum.hazard.function.control(survival.data.control$time,k,h0)
survival.data.control$Nalen.Aalen=nelsonaalen(data=survival.data.control,timevar=cum.hazard.est,statusvar=status)
ggplot(data=survival.data.control,aes(x=cum.hazard.est,y=Nalen.Aalen))+geom_stephazard()+geom_abline(intercept = 0,slope=1,linetype=2)+xlab("Residual")+ylab("Estimated Cumulative Hazard Rates")

Parameters.treatment<-Parameters.estimation.treatment(theta.init,t1.init,t2.init,a.init,b.init,k,h0,Observation.time=survival.data.treatment$time,Censoring.identicator=survival.data.treatment$status,Group=survival.data.treatment$treat)
theta=Parameters.treatment$estimate[1]
t1=Parameters.treatment$estimate[2]
t2=Parameters.treatment$estimate[3]
a=Parameters.treatment$estimate[4]
b=Parameters.treatment$estimate[5]
survival.data.treatment$cum.hazard.est=cum.hazard.function.treatment(survival.data.treatment$time,k,h0,t1,t2,theta,a,b)
survival.data.treatment$Nalen.Aalen=nelsonaalen(data=survival.data.treatment,timevar=cum.hazard.est,statusvar=status)
ggplot(data=survival.data.treatment,aes(x=cum.hazard.est,y=Nalen.Aalen))+geom_stephazard()+geom_abline(intercept = 0,slope=1,linetype=2)+xlab("Residual")+ylab("Estimated Cumulative Hazard Rates")


Parameters.control.pweibull<-Parameters.estimation.control.pWeibull(k1.init=k.init,h1.init=h0.init,k2.init=k.init,h2.init=h0.init,tstar.init=3,Observation.time=survival.data.control$time,Censoring.identicator=survival.data.control$status,Group=survival.data.control$treat)
k1=Parameters.control.pweibull$estimate[1]
h1=Parameters.control.pweibull$estimate[2]
k2=Parameters.control.pweibull$estimate[3]
h2=Parameters.control.pweibull$estimate[4]
tstar=Parameters.control.pweibull$estimate[5]
survival.data.control$cum.hazard.est2=cum.hazard.function.control.pweibull(survival.data.control$time,k1,h1,k2,h2,tstar)
survival.data.control$Nalen.Aalen2=nelsonaalen(data=survival.data.control,timevar=cum.hazard.est,statusvar=status)
ggplot(data=survival.data.control,aes(x=cum.hazard.est2,y=Nalen.Aalen2))+geom_stephazard()+geom_abline(intercept = 0,slope=1,linetype=2)+xlab("Residual")+ylab("Estimated Cumulative Hazard Rates")

Parameters.treatment.pweibull<-Parameters.estimation.treatment.pweibull(theta.init,t1.init,t2.init,a.init,b.init,k1,h1,k2,h2,tstar,Observation.time=survival.data.treatment$time,Censoring.identicator=survival.data.treatment$status,Group=survival.data.treatment$treat)
theta=Parameters.treatment.pweibull$estimate[1]
t1=Parameters.treatment.pweibull$estimate[2]
t2=Parameters.treatment.pweibull$estimate[3]
a=Parameters.treatment.pweibull$estimate[4]
b=Parameters.treatment.pweibull$estimate[5]
survival.data.treatment$cum.hazard.est2=cum.hazard.function.treatment.pweibull(survival.data.treatment$time,k1,h1,k2,h2,tstar,t1,t2,theta,a,b)
survival.data.treatment$Nalen.Aalen2=nelsonaalen(data=survival.data.treatment,timevar=cum.hazard.est,statusvar=status)
ggplot(data=survival.data.treatment,aes(x=cum.hazard.est2,y=Nalen.Aalen2))+geom_stephazard()+geom_abline(intercept = 0,slope=1,linetype=2)+xlab("Residual")+ylab("Estimated Cumulative Hazard Rates")
Cox.snell.residual.dataplot<-data.frame(matrix(nrow=1598,ncol=4))
colnames(Cox.snell.residual.dataplot)<-c("cum.hazard.est","Nalen.Aalen","Baseline.hazard","Group")
for(i in 1:400)
{
  Cox.snell.residual.dataplot$cum.hazard.est[i]=survival.data.control$cum.hazard.est[i]
  Cox.snell.residual.dataplot$Nalen.Aalen[i]=survival.data.control$Nalen.Aalen[i]
  Cox.snell.residual.dataplot$Baseline.hazard[i]="Baseline: Weibull distribution"
  Cox.snell.residual.dataplot$Group[i]="Control group"
}
for(i in 401:800)
{
  Cox.snell.residual.dataplot$cum.hazard.est[i]=survival.data.control$cum.hazard.est2[i-400]
  Cox.snell.residual.dataplot$Nalen.Aalen[i]=survival.data.control$Nalen.Aalen2[i-400]
  Cox.snell.residual.dataplot$Baseline.hazard[i]="Baseline: piecewise Weibull distribution"
  Cox.snell.residual.dataplot$Group[i]="Control group"
}
for(i in 801:1199)
{
  Cox.snell.residual.dataplot$cum.hazard.est[i]=survival.data.treatment$cum.hazard.est[i-800]
  Cox.snell.residual.dataplot$Nalen.Aalen[i]=survival.data.treatment$Nalen.Aalen[i-800]
  Cox.snell.residual.dataplot$Baseline.hazard[i]="Baseline: Weibull distribution"
  Cox.snell.residual.dataplot$Group[i]="Immunotherapy group"
}
for(i in 1200:1598)
{
  Cox.snell.residual.dataplot$cum.hazard.est[i]=survival.data.treatment$cum.hazard.est2[i-1199]
  Cox.snell.residual.dataplot$Nalen.Aalen[i]=survival.data.treatment$Nalen.Aalen2[i-1199]
  Cox.snell.residual.dataplot$Baseline.hazard[i]="Baseline: piecewise Weibull distribution"
  Cox.snell.residual.dataplot$Group[i]="Immunotherapy group"
}
Cox.snell.residual.dataplot$Baseline.hazard<-factor(Cox.snell.residual.dataplot$Baseline.hazard,levels=c("Baseline: Weibull distribution","Baseline: piecewise Weibull distribution"))
Cox.snell.residual.dataplot$Group<-factor(Cox.snell.residual.dataplot$Group,levels=c("Control group","Immunotherapy group"))
dev.set()
cairo_ps("~/Figure_BoshengLi_A1.eps",width=12,height=9)
p<-ggplot(Cox.snell.residual.dataplot,aes(x=cum.hazard.est,y=Nalen.Aalen))+geom_stephazard(size=1)+geom_abline(intercept = 0,slope=1,linetype=2)+xlab("Residual")+ylab("Estimated Cumulative Hazard Rates")
p<-p+facet_wrap(Group~Baseline.hazard,scales="free")
p<-p+theme(axis.title=element_text(size=16),axis.text=element_text(size=16),strip.text =element_text(size=16))
p
dev.off()
save.image("Appendix2.RData")