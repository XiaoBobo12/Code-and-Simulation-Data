rm(list=ls())
load("D:/研究备份/研究3/固定样本设计/正式模拟结果/样本量精确性评估/Scenario.Ye.Yu.RData")
data.plot<-data.frame(matrix(nrow=30,ncol=6))
colnames(data.plot)=c("Allc","theta","tau","Lag.scenario","n","Empirical.power")
for(i in 1:30)
{
  simul.esti<-list.result[[i]]$simul.esti
  Allc=round(simul.esti$Parameters.list$nt/simul.esti$Parameters.list$nc)
  data.plot$Allc[i]=paste("n[1]/n[0]==",Allc,sep="")
  theta=simul.esti$Parameters.list$theta
  data.plot$theta[i]=theta
  tau=simul.esti$Parameters.list$tau
  data.plot$tau[i]=paste("tau==",tau,sep="")
  t1.true=simul.esti$Parameters.list$t1.true
  t2.true=simul.esti$Parameters.list$t2.true
  a=simul.esti$Parameters.list$a
  b=simul.esti$Parameters.list$b
  if(t1.true==1 & t2.true==1)
  {
    Lag.scenario=1
  }
  else if(t1.true==3 & t2.true==3)
  {
    Lag.scenario=2
  }
  else if(t1.true==1 & t2.true==3 & a==1 & b==1)
  {
    Lag.scenario=3
  }
  else if(t1.true==1 & t2.true==3 & a==2 & b==1)
  {
    Lag.scenario=4
  }
  else if(t1.true==1 & t2.true==3 & a==1 & b==2)
  {
    Lag.scenario=5
  }
  data.plot$Lag.scenario[i]=paste("Scenario",Lag.scenario,sep=" ")
  data.plot$n[i]=simul.esti$Parameters.list$nc+simul.esti$Parameters.list$nt
  data.plot$Empirical.power[i]=simul.esti$Power
}
data.plot$n.power=paste(data.plot$n,"(",data.plot$Empirical.power,")",sep="")
library("reshape2")
results.output=dcast(data.plot,Allc+theta+tau~Lag.scenario,value.var="n.power")
write.csv(file="Table6.csv",x=results.output)
data.plot$Allc=factor(data.plot$Allc)
data.plot$tau=factor(data.plot$tau)
data.plot$Lag.scenario=factor(data.plot$Lag.scenario)
library(ggplot2)
library(scales)
library(grDevices)
##Note: the range of mapping requires to be consistently reverse to ensure the mapping is reversible
dev.set()
cairo_ps("Figure6_BoshengLi.eps",width=8.4,height=7.7)
p<-ggplot(data.plot,aes(x=theta,linetype=Lag.scenario))
p<-p+geom_line(aes(y=n,colour="Sample size"))
p<-p+geom_line(aes(y=scales::rescale(Empirical.power,to=c(0,2000),from=c(0.88,0.92)),colour="Empirical power"))
p<-p+scale_y_continuous(sec.axis = sec_axis(name="Empirical power",~scales::rescale(.,from=c(0,2000),to=c(0.88,0.92))))+geom_hline(yintercept = 1000,linetype=2)
p<-p+facet_grid(tau~Allc,labeller = label_parsed)+xlab(expression(paste("Hazard ratio after the full onset of effect (",lambda,")")))+ylab("Sample size estimation")+labs(linetype="Lag scenario",colour="Symbol of curve")
p
dev.off()
