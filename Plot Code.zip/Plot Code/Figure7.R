rm(list=ls())
setwd("D:/�о�����/�о�3/�̶��������/ģ���龰����/����ʾ��")
source("Design.algorithm.R")
load("Appendix2.RData")
k=round(Parameters.control$estimate[1],3)
h0=round(Parameters.control$estimate[2],3)
theta=round(Parameters.treatment$estimate[1],3)
t1=round(Parameters.treatment$estimate[2],2)
t2=round(Parameters.treatment$estimate[3],2)
a=round(Parameters.treatment$estimate[4],3)
b=round(Parameters.treatment$estimate[5],3)
t.vec<-seq(0,20,0.1)
surv.frame<-data.frame(matrix(nrow=402,ncol=3))
colnames(surv.frame)<-c("t","Surv.prop","Group")
for(i in 1:201)
{
  surv.frame$t[i]=t.vec[i]
  surv.frame$Surv.prop[i]=survival.function.treatment(t.vec[i],k,h0,t1,t2,theta,a,b)*100
  surv.frame$Group[i]="Immunotherapy"
}
for(i in 202:402)
{
  surv.frame$t[i]=t.vec[i-201]
  surv.frame$Surv.prop[i]=survival.function.control(t.vec[i-201],k,h0)*100
  surv.frame$Group[i]="Control"
}
library(ggplot2)
dev.set()
cairo_ps("Figure71_BoshengLi.eps",width=12,height=6.5)
p<-ggplot(surv.frame,aes(x=t,y=Surv.prop,colour=Group))+geom_line(size=1)+xlab("Survival time (months)")+ylab("PFS (%)")
p<-p+theme(axis.title = element_text(size=16),axis.text = element_text(size=14),legend.text = element_text(size=14),legend.title=element_text(size=16))
p
dev.off()
hazard.frame<-data.frame(matrix(nrow=402,ncol=3))
colnames(hazard.frame)<-c("t","hazard","Group")
for(i in 1:201)
{
  hazard.frame$t[i]=t.vec[i]
  hazard.frame$hazard[i]=hazard.function.treatment(t.vec[i],k,h0,t1,t2,theta,a,b)*100
  hazard.frame$Group[i]="Immunotherapy"
}
for(i in 202:402)
{
  hazard.frame$t[i]=t.vec[i-201]
  hazard.frame$hazard[i]=hazard.function.control(t.vec[i-201],k,h0)*100
  hazard.frame$Group[i]="Control"
}
dev.set()
cairo_ps("Figure72_BoshengLi.eps",width=12,height=6.5)
p<-ggplot(hazard.frame,aes(x=t,y=hazard,colour=Group))+geom_line(size=1)+xlab("Survival time (months)")+ylab("Hazard function")
p<-p+theme(axis.title = element_text(size=16),axis.text = element_text(size=14),legend.text = element_text(size=14),legend.title=element_text(size=16))
p
dev.off()
hazard.ratio.frame<-data.frame(matrix(1,nrow=201,ncol=2))
colnames(hazard.ratio.frame)<-c("t","hazard.ratio")
for(i in 2:201)
{
  hazard.ratio.frame$t[i]=t.vec[i]
  hazard.ratio.frame$hazard.ratio[i]=hazard.frame$hazard[i]/hazard.frame$hazard[i+201]
}
dev.set()
cairo_ps("Figure73_BoshengLi.eps",width=12,height=6.5)
p<-ggplot(hazard.ratio.frame,aes(x=t,y=hazard.ratio))+geom_line(size=1)+xlab("Survival time (months)")+ylab("Hazard ratio")
p<-p+theme(axis.title = element_text(size=16),axis.text = element_text(size=14),legend.text = element_text(size=14),legend.title=element_text(size=16))
p
dev.off()
