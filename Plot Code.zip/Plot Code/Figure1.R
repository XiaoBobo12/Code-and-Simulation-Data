rm(list=ls())
load("D:/研究备份/研究3/固定样本设计/正式模拟结果/样本量精确性评估/Scenario.old.RData")
data.plot<-data.frame(matrix(nrow=150,ncol=6))
colnames(data.plot)=c("Allc","theta","tau","Lag.scenario","n","Empirical.power")
for(i in 1:150)
{
  simul.esti<-list.result[[i]]$simul.esti
  Allc=round(simul.esti$Parameters.list$nt/simul.esti$Parameters.list$nc)
  data.plot$Allc[i]=paste("n[1]/n[0]==",Allc,sep="")
  theta=simul.esti$Parameters.list$theta
  data.plot$theta[i]=theta
  tau=simul.esti$Parameters.list$tau
  data.plot$tau[i]=paste("tau==",tau,sep="")
  t1.true=simul.esti$Parameters.list$t1.true
  t2.true=simul.esti$Parameters.list$t2.true
  a=simul.esti$Parameters.list$a
  b=simul.esti$Parameters.list$b
  if(t1.true==1 & t2.true==1)
  {
    Lag.scenario=1
  }
  else if(t1.true==3 & t2.true==3)
  {
    Lag.scenario=2
  }
  else if(t1.true==1 & t2.true==3 & a==1 & b==1)
  {
    Lag.scenario=3
  }
  else if(t1.true==1 & t2.true==3 & a==2 & b==1)
  {
    Lag.scenario=4
  }
  else if(t1.true==1 & t2.true==3 & a==1 & b==2)
  {
    Lag.scenario=5
  }
  data.plot$Lag.scenario[i]=paste("Scenario",Lag.scenario,sep=" ")
  data.plot$n[i]=simul.esti$Parameters.list$nc+simul.esti$Parameters.list$nt
  data.plot$Empirical.power[i]=simul.esti$Power
}
data.plot$n.power=paste(data.plot$n,"(",data.plot$Empirical.power,")",sep="")
library(reshape2)
results.output=dcast(data.plot,Allc+theta+tau~Lag.scenario,value.var="n.power")
write.csv(file="Table1.csv",x=results.output)
data.plot$Allc=factor(data.plot$Allc)
data.plot$tau=factor(data.plot$tau)
data.plot$Lag.scenario=factor(data.plot$Lag.scenario)
library(ggplot2)
library(gridExtra)
dev.set()
cairo_ps("Figure1_BoshengLi.eps",width=17.5,height=15)
p1<-ggplot(data.plot,aes(x=theta,y=n,colour=Lag.scenario))+geom_line()+xlab(expression(paste("Hazard ratio after the full onset of effect (",lambda,")")))+ylab("Sample size estimation")+labs(colour="Lag scenario")+ylim(0,2300)
p1<-p1+facet_wrap(Allc~tau,labeller = label_parsed)+theme(axis.title = element_text(size=18),axis.text = element_text(size=14),legend.text = element_text(size=16),legend.title=element_text(size=18),strip.text = element_text(size=16))
p2<-ggplot(data.plot,aes(x=theta,y=Empirical.power,colour=Lag.scenario))+geom_line()+geom_hline(yintercept=0.9,linetype=2)+xlab(expression(paste("Hazard ratio after the full onset of effect (",lambda,")")))+ylab("Empirical power")+labs(colour="Lag scenario")+ylim(0.88,0.92)
p2<-p2+facet_wrap(Allc~tau,labeller = label_parsed)+theme(axis.title = element_text(size=18),axis.text = element_text(size=14),legend.text = element_text(size=16),legend.title=element_text(size=18),strip.text = element_text(size=16))
grid.arrange(p1, p2, ncol=1,nrow=2)
dev.off()