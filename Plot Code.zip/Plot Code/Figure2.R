rm(list=ls())
results<-data.frame(matrix(nrow=30,ncol=8))
data.plot<-data.frame(matrix(nrow=150,ncol=6))
colnames(results)<-c("Allc","theta","tau","l.t1","l.t2","l.t1.t2.1.1","l.t1.t2.2.1","l.t1.t2.1.2")
colnames(data.plot)=c("Allc","theta","tau","Lag.scenario","n","Empirical.power")
for(i in 1:3)
{
  for(j in 1:5)
  {
    for(l in 1:10)
    {
      if(j==1&l<10)
      {
        order.num=i*10+l
      }else
      {
        order.num=i*100+(j-1)*10+l
      }
      print(order.num)
      str=paste("~/Simulation Data Simulation Experiment 2/Scenario",order.num,".RData",sep="")
      load(str)
      if(j==1)
      {
        results$Allc[(i-1)*10+l]=Allc
        results$theta[(i-1)*10+l]=theta
        results$tau[(i-1)*10+l]=tau
      }
      results[(i-1)*10+l,j+3]=paste(sample.size.esti$n,"(",simul.esti$Power,")",sep="")
      data.plot$Allc[(i-1)*50+(j-1)*10+l]=paste("n[1]/n[0]==",Allc,sep="")
      data.plot$theta[(i-1)*50+(j-1)*10+l]=theta
      data.plot$tau[(i-1)*50+(j-1)*10+l]=paste("tau==",tau,sep="")
      data.plot$Lag.scenario[(i-1)*50+(j-1)*10+l]=paste("Scenario",j,sep=" ")
      data.plot$n[(i-1)*50+(j-1)*10+l]=sample.size.esti$n
      data.plot$Empirical.power[(i-1)*50+(j-1)*10+l]=simul.esti$Power
    }
  }
}
results.store<-results[,c(1,2,3,4,5,6,8,7)]
write.csv(file="~/Table2.csv",x=results.store)
data.plot$Allc=factor(data.plot$Allc)
data.plot$tau=factor(data.plot$tau)
data.plot$Lag.scenario=factor(data.plot$Lag.scenario)
library(ggplot2)
library(scales)
##Note: the range of mapping requires to be consistently reverse to ensure the mapping is reversible
dev.set()
cairo_ps("~/Figure2_BoshengLi.eps",width=8.4,height=7.7)
p<-ggplot(data.plot,aes(x=theta,colour=Lag.scenario))
p<-p+geom_line(aes(y=n,linetype="1"))
p<-p+geom_line(aes(y=scales::rescale(Empirical.power,to=c(0,2000),from=c(0.88,0.92)),linetype="2"))
p<-p+scale_y_continuous(sec.axis = sec_axis(name="Empirical power",~scales::rescale(.,from=c(0,2000),to=c(0.88,0.92))))
p<-p+facet_grid(tau~Allc,scales = "free",labeller = label_parsed)+xlab("Hazard ratio after the full onset of effect")+ylab("Sample size")+labs(colour="Lag scenario",linetype="Symbol of curve")
p<-p+scale_linetype_discrete(labels=c("Sample size","Empirical power"))
p
dev.off()
