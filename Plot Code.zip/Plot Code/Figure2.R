rm(list=ls())
load("D:/�о�����/�о�3/�̶��������/��ʽģ����/��������ȷ������/Scenario.proposed.RData")
data.plot<-data.frame(matrix(nrow=150,ncol=6))
colnames(data.plot)=c("Allc","theta","tau","Lag.scenario","n","Empirical.power")
for(i in 1:150)
{
  simul.esti<-list.result[[i]]$simul.esti
  Allc=round(simul.esti$Parameters.list$nt/simul.esti$Parameters.list$nc)
  data.plot$Allc[i]=paste("n[1]/n[0]==",Allc,sep="")
  theta=simul.esti$Parameters.list$theta
  data.plot$theta[i]=theta
  tau=simul.esti$Parameters.list$tau
  data.plot$tau[i]=paste("tau==",tau,sep="")
  t1.true=simul.esti$Parameters.list$t1.true
  t2.true=simul.esti$Parameters.list$t2.true
  a=simul.esti$Parameters.list$a
  b=simul.esti$Parameters.list$b
  if(t1.true==1 & t2.true==1)
  {
    Lag.scenario=1
  }
  else if(t1.true==3 & t2.true==3)
  {
    Lag.scenario=2
  }
  else if(t1.true==1 & t2.true==3 & a==1 & b==1)
  {
    Lag.scenario=3
  }
  else if(t1.true==1 & t2.true==3 & a==2 & b==1)
  {
    Lag.scenario=4
  }
  else if(t1.true==1 & t2.true==3 & a==1 & b==2)
  {
    Lag.scenario=5
  }
  data.plot$Lag.scenario[i]=paste("Scenario",Lag.scenario,sep=" ")
  data.plot$n[i]=simul.esti$Parameters.list$nc+simul.esti$Parameters.list$nt
  data.plot$Empirical.power[i]=simul.esti$Power
}
data.plot$n.power=paste(data.plot$n,"(",data.plot$Empirical.power,")",sep="")
library("reshape2")
results.output=dcast(data.plot,Allc+theta+tau~Lag.scenario,value.var="n.power")
write.csv(file="~/Table1.csv",x=results.output)
data.plot$Allc=factor(data.plot$Allc)
data.plot$tau=factor(data.plot$tau)
data.plot$Lag.scenario=factor(data.plot$Lag.scenario)
data.plot2<-data.frame(matrix(nrow=300,ncol=6))
colnames(data.plot2)=c("Allc","theta","tau","Lag.scenario","Variable","Variable.value")
for(i in 1:150)
{
  data.plot2$Allc[2*i-1]=as.character(data.plot$Allc[i])
  data.plot2$Allc[2*i]=as.character(data.plot$Allc[i])
  data.plot2$theta[2*i-1]=data.plot$theta[i]
  data.plot2$theta[2*i]=data.plot$theta[i]
  data.plot2$tau[2*i-1]=as.character(data.plot$tau[i])
  data.plot2$tau[2*i]=as.character(data.plot$tau[i])
  data.plot2$Lag.scenario[2*i-1]=as.character(data.plot$Lag.scenario[i])
  data.plot2$Lag.scenario[2*i]=as.character(data.plot$Lag.scenario[i])
  data.plot2$Variable[2*i-1]="Variable: sample ~ size"
  data.plot2$Variable.value[2*i-1]=data.plot$n[i]
  data.plot2$Variable[2*i]="Variable: empirical ~ power"
  data.plot2$Variable.value[2*i]=data.plot$Empirical.power[i]
}
data.plot2$Allc=factor(data.plot2$Allc)
data.plot2$tau=factor(data.plot2$tau)
data.plot2$Lag.scenario=factor(data.plot2$Lag.scenario)
data.plot2$Variable=factor(data.plot2$Variable,levels=c("Variable: sample ~ size","Variable: empirical ~ power"),labels=c("Variable: sample ~ size","Variable: empirical ~ power"))
library(ggplot2)
dev.set()
cairo_ps("~/Figure2_BoshengLi.eps",width=21,height=14)
p<-ggplot(data.plot2,aes(x=theta,y=Variable.value,colour=Lag.scenario))+geom_line()+xlab("Hazard ratio after the full onset of effect")+ylab("Values of variables")+labs(colour="Lag scenario",linetype="Symbol of curve")
p<-p+facet_wrap(tau~Allc~Variable,labeller = label_parsed,scales="free")+theme(axis.title = element_text(size=18),axis.text = element_text(size=14),legend.text = element_text(size=16),legend.title=element_text(size=18),strip.text = element_text(size=16))
p
dev.off()