rm(list=ls())
setwd("D:/研究备份/研究3/固定样本设计/模拟情景代码/生存模型拟合评估及比较")
load("Fit.Data.goodness.evaluation11.RData")
load("Fit.Data.goodness.evaluation11_2.RData")
Dev.joint.pweibull<-Joint.parameter.pweibull.local.optim$maximum*(-2)
AIC.joint.pweibull<-Dev.joint.pweibull+2*10
BIC.joint.pweibull<-Dev.joint.pweibull+10*log(nrow(Survival.data.overall))
Dev.joint.pweibull.Ye.Yu<-Joint.parameter.pweibull.local.optim.Ye.Yu$maximum*(-2)
AIC.joint.pweibull.Ye.Yu<-Dev.joint.pweibull.Ye.Yu+2*8
BIC.joint.pweibull.Ye.Yu<-Dev.joint.pweibull.Ye.Yu+8*log(nrow(Survival.data.overall))
LR.Test<-Dev.joint.pweibull.Ye.Yu-Dev.joint.pweibull
critical.value<-qchisq(0.95,2)
parameters<-Joint.parameter.pweibull.local.optim$estimate
k1=parameters[1]
h1=parameters[2]
k2=parameters[3]
h2=parameters[4]
k3=parameters[5]
h3=parameters[6]
tstar1=parameters[7]
tstar2=parameters[7]+parameters[8]
theta=parameters[9]
t1.true=parameters[10]
dif.t1.t2=parameters[11]
t2.true=t1.true+dif.t1.t2
a=parameters[12]
b=parameters[13]
library(mice)
survival.data.control$cum.hazard.para=cum.hazard.function.control.pweibull(survival.data.control$time,k1,h1,k2,h2,k3,h3,tstar1,tstar2)
survival.data.control$Nalen.Aalen=nelsonaalen(data=survival.data.control,timevar=cum.hazard.para,statusvar=status)
survival.data.treatment$cum.hazard.para=cum.hazard.function.treatment.pweibull(survival.data.treatment$time,k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1.true,t2.true,theta,a,b)
survival.data.treatment$Nalen.Aalen=nelsonaalen(data=survival.data.treatment,timevar=cum.hazard.para,statusvar=status)
parameters<-Joint.parameter.pweibull.local.optim.Ye.Yu$estimate
k1=parameters[1]
h1=parameters[2]
k2=parameters[3]
h2=parameters[4]
k3=parameters[5]
h3=parameters[6]
tstar1=parameters[7]
tstar2=parameters[7]+parameters[8]
theta=parameters[9]
t1.true=parameters[10]
dif.t1.t2=parameters[11]
t2.true=t1.true+dif.t1.t2
a=1
b=1
survival.data.control$cum.hazard.para2=cum.hazard.function.control.pweibull(survival.data.control$time,k1,h1,k2,h2,k3,h3,tstar1,tstar2)
survival.data.control$Nalen.Aalen2=nelsonaalen(data=survival.data.control,timevar=cum.hazard.para2,statusvar=status)
survival.data.treatment$cum.hazard.para2=cum.hazard.function.treatment.pweibull(survival.data.treatment$time,k1,h1,k2,h2,k3,h3,tstar1,tstar2,t1.true,t2.true,theta,a,b)
survival.data.treatment$Nalen.Aalen2=nelsonaalen(data=survival.data.treatment,timevar=cum.hazard.para2,statusvar=status)
Cox.snell.residual.control<-data.frame(matrix(nrow=800,ncol=4))
colnames(Cox.snell.residual.control)<-c("cum.hazard.para","Nalen.Aalen","Fitted.approach","Group")
for(i in 1:400)
{
  Cox.snell.residual.control$cum.hazard.para[i]=survival.data.control$cum.hazard.para[i]
  Cox.snell.residual.control$Nalen.Aalen[i]=survival.data.control$Nalen.Aalen[i]
  Cox.snell.residual.control$Fitted.approach[i]="1"
}
for(i in 401:800)
{
  Cox.snell.residual.control$cum.hazard.para[i]=survival.data.control$cum.hazard.para2[i-400]
  Cox.snell.residual.control$Nalen.Aalen[i]=survival.data.control$Nalen.Aalen2[i-400]
  Cox.snell.residual.control$Fitted.approach[i]="2"
}
Cox.snell.residual.control$Group="Control"
library(ggplot2)
library(pammtools)
Cox.snell.residual.trt<-data.frame(matrix(nrow=798,ncol=4))
colnames(Cox.snell.residual.trt)<-c("cum.hazard.para","Nalen.Aalen","Fitted.approach","Group")
for(i in 1:399)
{
  Cox.snell.residual.trt$cum.hazard.para[i]=survival.data.treatment$cum.hazard.para[i]
  Cox.snell.residual.trt$Nalen.Aalen[i]=survival.data.treatment$Nalen.Aalen[i]
  Cox.snell.residual.trt$Fitted.approach[i]="1"
}
for(i in 400:798)
{
  Cox.snell.residual.trt$cum.hazard.para[i]=survival.data.treatment$cum.hazard.para2[i-399]
  Cox.snell.residual.trt$Nalen.Aalen[i]=survival.data.treatment$Nalen.Aalen2[i-399]
  Cox.snell.residual.trt$Fitted.approach[i]="2"
}
Cox.snell.residual.trt$Group="Immunotherapy"
Cox.snell.residual<-rbind(Cox.snell.residual.control,Cox.snell.residual.trt)
library(ggplot2)
p<-ggplot(Cox.snell.residual,aes(x=cum.hazard.para,y=Nalen.Aalen,colour=Fitted.approach))+geom_stephazard(linewidth=1)+geom_abline(intercept = 0,slope=1,linetype=2)+xlab("Cumulative Hazard Rates obtained from the fitted survival model")+ylab("Nelson-Aalen estimation of the Cumulative Hazard Rates")
p<-p+theme(axis.title=element_text(size=16),axis.text=element_text(size=16),legend.title=element_text(size=16),legend.text =element_text(size=16),strip.text=element_text(size=16))
p<-p+scale_color_discrete(name="Fitted survival model",breaks=c("1","2"),labels=c("Survival model of\nYe and Yu(2018)","Proposed\nsurvival model"))
p<-p+facet_wrap(.~Group,labeller = label_parsed,ncol=1,scales = "free")
p
ggsave(p,filename = "Cox.snell.group.jpg",width = 9,height=11.5)
