rm(list=ls())
results<-data.frame(matrix(nrow=30,ncol=8))
data.plot<-data.frame(matrix(nrow=150,ncol=6))
colnames(results)<-c("Allc","theta","tau","l.t1","l.t2","l.t1.t2.1.1","l.t1.t2.2.1","l.t1.t2.1.2")
colnames(data.plot)=c("Allc","theta","tau","Lag.scenario","n","Empirical.power")
for(l in 1:3)
{
  for(m in 1:5)
  {
    for(n in 1:10)
    {
      order.num=paste(l,(m-1)*10+n,sep = "")
      print(order.num)
      str=paste("~/Simulation Data Simulation Experiment 3/Scenario",order.num,".RData",sep="")
      load(str)
      if(m==1)
      {
        results$Allc[(l-1)*10+n]=Allc
        results$theta[(l-1)*10+n]=theta
        results$tau[(l-1)*10+n]=tau
      }
      results[(l-1)*10+n,m+3]=paste(sample.size.esti$n,"(",simul.esti$Power,")",sep="")
      data.plot$Allc[(l-1)*50+(m-1)*10+n]=paste("n[1]/n[0]==",Allc,sep="")
      data.plot$theta[(l-1)*50+(m-1)*10+n]=theta
      data.plot$tau[(l-1)*50+(m-1)*10+n]=paste("tau==",tau,sep="")
      data.plot$Lag.scenario[(l-1)*50+(m-1)*10+n]=paste("Scenario",m,sep=" ")
      data.plot$n[(l-1)*50+(m-1)*10+n]=sample.size.esti$n
      print(simul.esti$Power)
      data.plot$Empirical.power[(l-1)*50+(m-1)*10+n]=simul.esti$Power
    }
  }
}
results.store<-results[,c(1,2,3,4,5,6,8,7)]
write.csv(file="~/Table3.csv",x=results.store)
data.plot$Allc=factor(data.plot$Allc)
data.plot$tau=factor(data.plot$tau)
data.plot$Lag.scenario=factor(data.plot$Lag.scenario)
library(ggplot2)
library(scales)
##Note: the range of mapping requires to be consistently reverse to ensure the mapping is reversible
dev.set()
cairo_ps("~/Figure3_BoshengLi.eps",width=8.4,height=7.7)
p<-ggplot(data.plot,aes(x=theta,colour=Lag.scenario))
p<-p+geom_line(aes(y=n,linetype="1"))
p<-p+geom_line(aes(y=scales::rescale(Empirical.power,to=c(0,2000),from=c(0.89,0.91)),linetype="2"))
p<-p+scale_y_continuous(sec.axis = sec_axis(name="Empirical power",~scales::rescale(.,from=c(0,2000),to=c(0.89,0.91))))
p<-p+facet_grid(tau~Allc,scales = "free",labeller = label_parsed)+xlab("Hazard ratio after the full onset of effect")+ylab("Sample size")+labs(colour="Lag scenario",linetype="Symbol of curve")
p<-p+scale_linetype_discrete(labels=c("Sample size","Empirical power"))
p
dev.off()

